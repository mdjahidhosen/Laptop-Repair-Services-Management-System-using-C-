﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmReceptionist : Form
    {
        public static string name;
        public frmReceptionist()
        {
            InitializeComponent();
        }
        public frmReceptionist(string n)
        {
            InitializeComponent();
            name = n;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var f1 = new frmRegistration();
            f1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmUpdateRecep f1 = new frmUpdateRecep();
            f1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmServicePayment f1 = new frmServicePayment();
            f1.Show();
            this.Hide();
        }

        private void frmReceptionist_Load(object sender, EventArgs e)
        {

        }
    }
}
