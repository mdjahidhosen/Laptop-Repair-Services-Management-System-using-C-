﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Text.RegularExpressions;
using System.IO;

namespace Group1
{
    public partial class frmRegistration : Form
    {
        public frmRegistration()
        {
            InitializeComponent();
        }
        private void frmRegistration_Load(object sender, EventArgs e)
        {
            BindData();
            clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            UserLogin f2 = new UserLogin();
            f2.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                MessageBox.Show("Please Confirm The Details");
            }
            else if (checkBox1.Checked == true)
            {
                if (txtftname.Text.Trim() == "" || txtscname.Text.Trim() == "" || txtUsername.Text.Trim() == "" || txtphone.Text.Trim() == "" || txtemail.Text.Trim() == "" || txticnum.Text.Trim() == "" || txtaddress.Text.Trim() == "" || txtpass.Text.Trim() == "" || txtconpass.Text.Trim() == "")
                {
                    MessageBox.Show("Data Incompleted");
                }
                else
                {
                    RegCust obj1 = new RegCust(txtftname.Text, txtscname.Text, txtUsername.Text, txtphone.Text, txticnum.Text, DateBirth.Text, txtemail.Text, txtaddress.Text, txtpass.Text, txtconpass.Text);
                    MessageBox.Show(obj1.RegisterCustomer());

                    /*SqlCommand cmd = new SqlCommand("insert into [Registration] (FirstName,LastName,UserRole,Username,PhoneNumber,ICPassport,BirthDate,Email,Address,Password,ConfirmPassword) values ('"+txtftname.Text+ "', '" + txtscname.Text + "','" + "Customer" + "','" + txtUsername.Text + "','" + txtphone.Text + "','" + txticnum.Text + "','" + DateBirth.Text + "','" + txtemail.Text + "','" + txtaddress.Text + "','" + txtpass.Text + "','" + txtconpass.Text + "')";
                        /*" FirstName = '" + txtftname.Text + "', LastName = '" + txtscname.Text + "', PhoneNumber  = '" + txtphone.Text + "', BirthDate = '" + this.DateBirth.Text + "' , Email = '" + txtemail.Text + "', Address = '" + txtaddress.Text + "', Password = '" + txticnum.Text + "', ConfirmPassword = '" + txtconpass.Text + "', Username = '" + txtUsername.Text + "'", cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sucessfully Registered", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    try
                    {
                        cn.Open();
                        SqlCommand cmd = new SqlCommand("insert into Registration set FirstName = '" + txtftname.Text + "', LastName = '" + txtscname.Text + "', PhoneNumber  = '" + txtphone.Text + "', BirthDate = '" + this.DateBirth.Text + "' , Email = '" + txtemail.Text + "', Address = '" + txtaddress.Text + "', Password = '" + txtpass.Text + "', ConfirmPassword = '" + txtconpass.Text + "', Username = '" + txtUsername.Text + "'", cn);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Sucessfully Registered", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception X)
                    {
                        MessageBox.Show(X.ToString());
                    }
                    /*cn.ConnectionString = ConfigurationManager.ConnectionStrings["Assignment.Properties.Settings.CustomerConnectionString"].ToString();
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("Update Registration set FirstName = '" + txtftname.Text + "', LastName = '" + txtscname.Text + "', PhoneNumber  = '" + txtphone.Text + "', BirthDate = '" + this.DateBirth.Text + "' , Email = '" + txtemail.Text + "', Address = '" + txtaddress.Text + "', Password = '" + txtpass.Text + "', ConfirmPassword = '" + txtconpass.Text + "' where Username = '" + int.Parse(txtUsername.Text) + "'", cn);
                    cmd.ExecuteNonQuery();*/

                }
            }
        }
        void clear()
        {
            txtftname.Text = "";
            txtscname.Text = "";
            txtUsername.Text = "";
            txtphone.Text = "";
            txtemail.Text = "";
            txticnum.Text = "";
            txtaddress.Text = "";
            txtpass.Text = "";
            txtconpass.Text = "";
        }
        void BindData()
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmReceptionist f1 = new frmReceptionist();
            f1.Show();
            this.Hide();
        }
    }
}
