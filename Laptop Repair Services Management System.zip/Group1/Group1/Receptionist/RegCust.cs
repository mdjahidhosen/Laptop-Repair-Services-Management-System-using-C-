﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections;

namespace Group1
{
    internal class RegCust
    {
        private string FirstName;
        private string LastName;
        private string Username;
        private string PhoneNumber;
        private string ICPassport;
        private string BirthDate;
        private string Email;
        private string Address;
        private string Password;
        private string ConfirmPassword;

        static SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public string firstName { get => FirstName; set => FirstName = value; }
        public string lastName { get => LastName; set => LastName = value; }
        public string username { get => Username; set => Username = value; }
        public string phoneNumber { get => PhoneNumber; set => PhoneNumber = value; }
        public string icPassport { get => ICPassport; set => ICPassport = value; }
        public string birthDate { get => BirthDate; set => BirthDate = value; }
        public string email { get => Email; set => Email = value; }
        public string address { get => Address; set => Address = value; }
        public string password { get => Password; set => Password = value; }
        public string confirmPassword { get => ConfirmPassword; set => ConfirmPassword = value; }

        public RegCust(string f, string l, string u, string phn, string ic, string b, string e, string a, string pass, string conpass)
        {
            FirstName = f;
            LastName = l;
            Username = u;
            PhoneNumber = phn;
            ICPassport = ic;
            BirthDate = b;
            Email = e;
            Address = a;
            Password = pass;
            ConfirmPassword = conpass;

        }

        public RegCust(string u)
        {
            FirstName = u;
        }


        public string RegisterCustomer()
        {
            string status;
            cn.Open();

            if ((Password != ConfirmPassword) && (Password != " ") && (ConfirmPassword != " "))
                status = "Password does not match";
            else
            {
                SqlCommand cmd = new SqlCommand("insert into Registration (FirstName,LastName,UserRole, Username,PhoneNumber,ICPassport,BirthDate,Email,Address, Password,ConfirmPassword) values(@ftname,@ltname,'Customer', @username,@pn,@ip,@birth,@email,@address,@pass,@cpw)", cn);
                


                cmd.Parameters.AddWithValue("@ftname", FirstName);
                cmd.Parameters.AddWithValue("@ltname", LastName);
                cmd.Parameters.AddWithValue("@username", Username);
                cmd.Parameters.AddWithValue("@pn", PhoneNumber);
                cmd.Parameters.AddWithValue("@ip", ICPassport);
                cmd.Parameters.AddWithValue("@birth", BirthDate);
                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@address", Address);
                cmd.Parameters.AddWithValue("@pass", Password);
                cmd.Parameters.AddWithValue("@cpw", ConfirmPassword);

               
                int i = cmd.ExecuteNonQuery();
                if (i != 0)
                    status = "Thankyou, your Registration Successful";
                else
                    status = "Failed to register, Sorry";

            }

            cn.Close();
            return status;

        }
    }
}
