﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmUpdateRecep : Form
    {
        public frmUpdateRecep()
        {
            InitializeComponent();
        }

        private void chkConfirm_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Receptionist obj1 = new Receptionist(txtMemid.Text);
            obj1.MemberID1 = txtMemid.Text;
            MessageBox.Show(obj1.updateReceptionist(txtFirstName.Text, txtLastName.Text, txtUsername.Text, txtPhoneNum.Text, txtICP.Text, this.dtp1.Text, txtEmail.Text, txtAdd.Text, txtPass.Text, txtCPass.Text));

            Clear();
        }
        private void Clear()
        {
            txtAdd.Text = " ";
            txtCPass.Text = "";
            txtEmail.Text = " ";
            txtFirstName.Text = " ";
            txtLastName.Text = " ";
            txtPhoneNum.Text = " ";
            txtUsername.Text = " ";
            txtICP.Text = " ";
            txtPass.Text = "";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmReceptionist f1 = new frmReceptionist();
            f1.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            UserLogin f2 = new UserLogin();
            f2.Show();
        }

        private void frmUpdateRecep_Load(object sender, EventArgs e)
        {

        }
    }
}
