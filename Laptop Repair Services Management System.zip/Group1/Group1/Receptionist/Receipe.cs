﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

namespace Group1
{
    internal class Receipe
    {
        private string Payment;
        private string Date;
        private string Email;
        private string OrderID;
        private string Username;
        private string Service;
        private string ServiceType;
        private string ServicePrice;
        private string PaymentMethods;
        private string PaymentDate;
        private string TotalAmount;

        static SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public string OrderID1 { get => OrderID; set => OrderID = value; }
        public string ServiceType1 { get => ServiceType; set => ServiceType = value; }
        public string ServicePrice1 { get => ServicePrice; set => ServicePrice = value; }
        public string PaymentMethods1 { get => PaymentMethods; set => PaymentMethods = value; }
        public string PaymentDate1 { get => PaymentDate; set => PaymentDate = value; }
        public string Service1 { get => Service; set => Service = value; }
        public string Username1 { get => Username; set => Username = value; }
        public string Date1 { get => Date; set => Date = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Payment1 { get => Payment; set => Payment = value; }
        public string TotalAmount1 { get => TotalAmount; set => TotalAmount = value; }

        public Receipe(string id, string un, string pm, string pd, string sr, string st, string sp)
        {
            OrderID = id;
            Username = un;
            PaymentMethods = pm;
            PaymentDate = pd;
            Service = sr;
            ServiceType = st;
            ServicePrice = sp;

        }
        public Receipe(string em, string un, string ta, string pm, string pd, string sr, string st, string sp)
        {
            Email = em;
            Username = un;
            Payment = pm;
            Date = pd;
            Service = sr;
            ServiceType = st;
            ServicePrice = sp;
            TotalAmount = ta;

        }
        public Receipe(string oid)
        {
            OrderID = oid;
        }
        public static void viewPayment1(Receipe o1)
        {

            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Services where OrderID='" + o1.OrderID1 + "'", cn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                o1.Username1 = dr.GetString(1);
                o1.Service1 = dr.GetString(4);
                o1.ServicePrice1 = dr.GetDecimal(6).ToString();
                o1.ServiceType1 = dr.GetString(5);
            }
            cn.Close();

        }
        public string addPayment()
        {
            string status;
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into Payment(Username, Service, ServiceType, ServicePrice, PaymentMethods, PaymentDate) values (@user, @serv, @sertyp, @serprice, @paymet, @paydat)", cn);
            cmd.Parameters.AddWithValue("@user", Username);
            cmd.Parameters.AddWithValue("@serv", Service);
            cmd.Parameters.AddWithValue("@sertyp", ServiceType);
            cmd.Parameters.AddWithValue("@serprice", ServicePrice);
            cmd.Parameters.AddWithValue("@paymet", PaymentMethods);
            cmd.Parameters.AddWithValue("@paydat", PaymentDate);


            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Your Payment has been sent ";
            else
                status = "Request Failed";
            cn.Close();
            return status;
        }
        public string addService()
        {
            string status;
            cn.Open();
            SqlCommand cmd2 = new SqlCommand("insert into Services(Username, Date, Email, Service, ServiceType, ServicePrice, TotalAmount, Payment) values (@user, @dat, @ema, @serv, @sertyp, @serprice, @tam, @paym)", cn);
            cmd2.Parameters.AddWithValue("@user", Username);
            cmd2.Parameters.AddWithValue("@dat", Date);
            cmd2.Parameters.AddWithValue("@ema", Email);
            cmd2.Parameters.AddWithValue("@serv", Service);
            cmd2.Parameters.AddWithValue("@sertyp", ServiceType);
            cmd2.Parameters.AddWithValue("@serprice", ServicePrice);
            cmd2.Parameters.AddWithValue("@tam", TotalAmount);
            cmd2.Parameters.AddWithValue("@paym", Payment);

            int i = cmd2.ExecuteNonQuery();
            if (i != 0)
                status = "and Your Requested Service On process ";
            else
                status = "Request Failed";
            cn.Close();
            return status;
        }
    }
}
