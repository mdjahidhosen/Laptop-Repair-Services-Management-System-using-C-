﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Group1
{
    public partial class frmServicePayment : Form
    {
        public frmServicePayment()
        {
            InitializeComponent();
        }

        private void frmServicePayment_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Remove virus, malware or spyware");
            comboBox1.Items.Add("Troubleshot and fix computer running slow");
            comboBox1.Items.Add("Laptop screen replacement");
            comboBox1.Items.Add("Laptop keyboard replacement");
            comboBox1.Items.Add("Laptop battery replacement");
            comboBox1.Items.Add("Operating System Format and Installation");
            comboBox1.Items.Add("Data backup and recovery");
            comboBox1.Items.Add("Internet connectivity issues");
            comboBox2.Items.Add("Normal");
            comboBox2.Items.Add("Urgent");
            comboBox3.Items.Add("Shopee Pay");
            comboBox3.Items.Add("Maybank");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Receipe obj1 = new Receipe(txtEmail.Text, txtUsername.Text, comboBox3.Text, dtp1.Text, comboBox1.Text, comboBox2.Text, lblPrice.Text);

            MessageBox.Show(obj1.addPayment());

            Receipe obj2 = new Receipe(txtEmail.Text, txtUsername.Text, lblPrice.Text, comboBox3.Text, dtp1.Text, comboBox1.Text, comboBox2.Text, lblPrice.Text);
            MessageBox.Show(obj2.addService());

            txtResult.Clear();
            txtResult.Text += "*****************************************\n";
            txtResult.Text += "****               Your Fees Is           ****\n";
            txtResult.Text += "*****************************************\n";
            txtResult.Text += "Date :" + this.dtp1.Text + "\n\n";

            txtResult.Text += "Thak you  " + txtUsername.Text + "  For trusting Us" + "\n\n";
            txtResult.Text += "Your Email  :" + txtEmail.Text + "\n\n";
            txtResult.Text += "Service  :" + comboBox1.Text + "\n\n";
            txtResult.Text += "Type Service  :" + comboBox2.Text + "\n\n";
            txtResult.Text += "Service Fees  :" + lblPrice.Text + " RM\n\n";
            txtResult.Text += "Payment Methods  :" + comboBox3.Text + "\n\n";

            txtResult.Text += "\n                                Signature";
            Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Receipe obj2 = new Receipe(txtEmail.Text);
            Receipe.viewPayment1(obj2);

            txtUsername.Text = obj2.Username1;
            comboBox1.Text = obj2.Service1;
            comboBox2.Text = obj2.ServiceType1;
            lblPrice.Text = obj2.ServicePrice1;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }
        private void Clear()
        {
            txtUsername.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            lblPrice.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmReceptionist f1 = new frmReceptionist();
            f1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            UserLogin f2 = new UserLogin();
            f2.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Remove virus, malware or spyware")
            {
                lblPrice.Text = "50";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Remove virus, malware or spyware")
            {
                lblPrice.Text = "80";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Troubleshot and fix computer running slow")
            {
                lblPrice.Text = "60";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Troubleshot and fix computer running slow")
            {
                lblPrice.Text = "90";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop screen replacement")
            {
                lblPrice.Text = "380";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop screen replacement")
            {
                lblPrice.Text = "430";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop keyboard replacement")
            {
                lblPrice.Text = "160";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop keyboard replacement")
            {
                lblPrice.Text = "200";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop battery replacement")
            {
                lblPrice.Text = "180";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop battery replacement")
            {
                lblPrice.Text = "210";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Operating System Format and Installation")
            {
                lblPrice.Text = "100";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Operating System Format and Installation")
            {
                lblPrice.Text = "150";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Data backup and recovery")
            {
                lblPrice.Text = "80";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Data backup and recovery")
            {
                lblPrice.Text = "130";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Internet connectivity issues")
            {
                lblPrice.Text = "70";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Internet connectivity issues")
            {
                lblPrice.Text = "100";
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
