﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmhomepage : Form
    {
        public frmhomepage()
        {
            InitializeComponent();
        }

        private void btntech_Click(object sender, EventArgs e)
        {
            frmtechpage reg_tech = new frmtechpage();
            reg_tech.Show();
        }

        private void btnreciption_Click(object sender, EventArgs e)
        {
            frmreceptionpage reg_recept = new frmreceptionpage();
            reg_recept.Show();
        }

        private void btnservice_Click(object sender, EventArgs e)
        {
            frmservicepage reg_service = new frmservicepage();
            reg_service.Show();
        }

        private void btnincome_Click(object sender, EventArgs e)
        {
            frmtotalpage reg_total = new frmtotalpage();
            reg_total.Show();
        }

        private void btnlogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
