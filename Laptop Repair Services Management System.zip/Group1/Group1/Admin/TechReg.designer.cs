﻿namespace Group1
{
    partial class frmtechpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmtechpage));
            this.btnback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.datetime = new System.Windows.Forms.DateTimePicker();
            this.txtconfirm = new System.Windows.Forms.TextBox();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.txtic = new System.Windows.Forms.TextBox();
            this.txtphone = new System.Windows.Forms.TextBox();
            this.lbldate = new System.Windows.Forms.Label();
            this.lblconfirmpass = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblic = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lbllastname = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnback
            // 
            this.btnback.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.Location = new System.Drawing.Point(109, 516);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(86, 32);
            this.btnback.TabIndex = 47;
            this.btnback.Text = "Back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnexit
            // 
            this.btnexit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(674, 516);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(98, 32);
            this.btnexit.TabIndex = 46;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(368, 469);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(123, 33);
            this.btnupdate.TabIndex = 45;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // datetime
            // 
            this.datetime.CustomFormat = "MM-dd-yyyy";
            this.datetime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetime.Location = new System.Drawing.Point(577, 404);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(185, 20);
            this.datetime.TabIndex = 44;
            // 
            // txtconfirm
            // 
            this.txtconfirm.Location = new System.Drawing.Point(577, 340);
            this.txtconfirm.Multiline = true;
            this.txtconfirm.Name = "txtconfirm";
            this.txtconfirm.Size = new System.Drawing.Size(185, 35);
            this.txtconfirm.TabIndex = 43;
            // 
            // txtpassword
            // 
            this.txtpassword.Location = new System.Drawing.Point(577, 269);
            this.txtpassword.Multiline = true;
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(185, 31);
            this.txtpassword.TabIndex = 42;
            // 
            // txtic
            // 
            this.txtic.Location = new System.Drawing.Point(577, 205);
            this.txtic.Multiline = true;
            this.txtic.Name = "txtic";
            this.txtic.Size = new System.Drawing.Size(185, 30);
            this.txtic.TabIndex = 41;
            // 
            // txtphone
            // 
            this.txtphone.Location = new System.Drawing.Point(577, 142);
            this.txtphone.Multiline = true;
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(185, 30);
            this.txtphone.TabIndex = 40;
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(462, 409);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(80, 19);
            this.lbldate.TabIndex = 39;
            this.lbldate.Text = "Birth Date";
            // 
            // lblconfirmpass
            // 
            this.lblconfirmpass.AutoSize = true;
            this.lblconfirmpass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconfirmpass.Location = new System.Drawing.Point(431, 341);
            this.lblconfirmpass.Name = "lblconfirmpass";
            this.lblconfirmpass.Size = new System.Drawing.Size(130, 19);
            this.lblconfirmpass.TabIndex = 38;
            this.lblconfirmpass.Text = "Confirm Password";
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.Location = new System.Drawing.Point(458, 277);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(72, 19);
            this.lblpassword.TabIndex = 37;
            this.lblpassword.Text = "Password";
            // 
            // lblic
            // 
            this.lblic.AutoSize = true;
            this.lblic.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblic.Location = new System.Drawing.Point(458, 214);
            this.lblic.Name = "lblic";
            this.lblic.Size = new System.Drawing.Size(84, 19);
            this.lblic.TabIndex = 36;
            this.lblic.Text = "ICPassport";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone.Location = new System.Drawing.Point(457, 143);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(104, 19);
            this.lblphone.TabIndex = 35;
            this.lblphone.Text = "Phone number";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(199, 405);
            this.txtemail.Multiline = true;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(180, 33);
            this.txtemail.TabIndex = 34;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(199, 342);
            this.txtcity.Multiline = true;
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(180, 33);
            this.txtcity.TabIndex = 33;
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(199, 269);
            this.txtlastname.Multiline = true;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(180, 31);
            this.txtlastname.TabIndex = 32;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(199, 205);
            this.txtname.Multiline = true;
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(180, 30);
            this.txtname.TabIndex = 31;
            // 
            // txtusername
            // 
            this.txtusername.Location = new System.Drawing.Point(199, 143);
            this.txtusername.Multiline = true;
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(180, 29);
            this.txtusername.TabIndex = 30;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.Location = new System.Drawing.Point(101, 404);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(47, 19);
            this.lblemail.TabIndex = 29;
            this.lblemail.Text = "Email";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(101, 341);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(64, 19);
            this.lbladdress.TabIndex = 28;
            this.lbladdress.Text = "Address";
            // 
            // lbllastname
            // 
            this.lbllastname.AutoSize = true;
            this.lbllastname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllastname.Location = new System.Drawing.Point(101, 270);
            this.lbllastname.Name = "lbllastname";
            this.lbllastname.Size = new System.Drawing.Size(83, 19);
            this.lbllastname.TabIndex = 27;
            this.lbllastname.Text = "Last Name";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(100, 204);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(84, 19);
            this.lblname.TabIndex = 26;
            this.lblname.Text = "First Name";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.Location = new System.Drawing.Point(100, 143);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(81, 19);
            this.lblusername.TabIndex = 25;
            this.lblusername.Text = "UserName";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.Location = new System.Drawing.Point(179, 20);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(507, 55);
            this.lbltitle.TabIndex = 24;
            this.lbltitle.Text = "Technician Registration";
            // 
            // frmtechpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(873, 569);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.txtconfirm);
            this.Controls.Add(this.txtpassword);
            this.Controls.Add(this.txtic);
            this.Controls.Add(this.txtphone);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.lblconfirmpass);
            this.Controls.Add(this.lblpassword);
            this.Controls.Add(this.lblic);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtlastname);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtusername);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lbllastname);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.lbltitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmtechpage";
            this.Text = "TechReg";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.DateTimePicker datetime;
        private System.Windows.Forms.TextBox txtconfirm;
        private System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.TextBox txtic;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lblconfirmpass;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblic;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lbllastname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lbltitle;
    }
}