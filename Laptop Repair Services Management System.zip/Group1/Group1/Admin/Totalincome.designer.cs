﻿namespace Group1
{
    partial class frmtotalpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmtotalpage));
            this.lbltitle = new System.Windows.Forms.Label();
            this.lblselect = new System.Windows.Forms.Label();
            this.cmbbox = new System.Windows.Forms.ComboBox();
            this.listBox = new System.Windows.Forms.ListBox();
            this.lblservicename = new System.Windows.Forms.Label();
            this.txtservicename = new System.Windows.Forms.TextBox();
            this.lblprice = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.txtupdown = new System.Windows.Forms.NumericUpDown();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnremove = new System.Windows.Forms.Button();
            this.datatable = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnreturn = new System.Windows.Forms.Button();
            this.btntotal = new System.Windows.Forms.Button();
            this.lblmonthytotal = new System.Windows.Forms.Label();
            this.lblrm = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txtupdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datatable)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.Location = new System.Drawing.Point(194, 9);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(489, 55);
            this.lbltitle.TabIndex = 0;
            this.lbltitle.Text = "Total income(monthly)";
            // 
            // lblselect
            // 
            this.lblselect.AutoSize = true;
            this.lblselect.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblselect.Location = new System.Drawing.Point(70, 99);
            this.lblselect.Name = "lblselect";
            this.lblselect.Size = new System.Drawing.Size(99, 19);
            this.lblselect.TabIndex = 1;
            this.lblselect.Text = "Select Month";
            // 
            // cmbbox
            // 
            this.cmbbox.FormattingEnabled = true;
            this.cmbbox.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cmbbox.Location = new System.Drawing.Point(44, 134);
            this.cmbbox.Name = "cmbbox";
            this.cmbbox.Size = new System.Drawing.Size(154, 21);
            this.cmbbox.TabIndex = 2;
            this.cmbbox.SelectedIndexChanged += new System.EventHandler(this.cmbbox_SelectedIndexChanged);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(3, 183);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(280, 290);
            this.listBox.TabIndex = 3;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // lblservicename
            // 
            this.lblservicename.AutoSize = true;
            this.lblservicename.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblservicename.Location = new System.Drawing.Point(289, 99);
            this.lblservicename.Name = "lblservicename";
            this.lblservicename.Size = new System.Drawing.Size(103, 19);
            this.lblservicename.TabIndex = 4;
            this.lblservicename.Text = "Service Name";
            // 
            // txtservicename
            // 
            this.txtservicename.Location = new System.Drawing.Point(398, 88);
            this.txtservicename.Multiline = true;
            this.txtservicename.Name = "txtservicename";
            this.txtservicename.Size = new System.Drawing.Size(207, 41);
            this.txtservicename.TabIndex = 5;
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.Location = new System.Drawing.Point(652, 99);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(43, 19);
            this.lblprice.TabIndex = 6;
            this.lblprice.Text = "Price";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(652, 168);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(43, 19);
            this.lbltotal.TabIndex = 7;
            this.lbltotal.Text = "Total";
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(714, 88);
            this.txtprice.Multiline = true;
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(132, 43);
            this.txtprice.TabIndex = 8;
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(714, 153);
            this.txttotal.Multiline = true;
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(132, 43);
            this.txttotal.TabIndex = 9;
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.Location = new System.Drawing.Point(300, 168);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(132, 19);
            this.lblcustomer.TabIndex = 10;
            this.lblcustomer.Text = "Customer Number";
            // 
            // txtupdown
            // 
            this.txtupdown.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtupdown.Location = new System.Drawing.Point(438, 164);
            this.txtupdown.Name = "txtupdown";
            this.txtupdown.Size = new System.Drawing.Size(151, 29);
            this.txtupdown.TabIndex = 11;
            this.txtupdown.ValueChanged += new System.EventHandler(this.txtupdown_ValueChanged);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.Location = new System.Drawing.Point(321, 207);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(120, 37);
            this.btnadd.TabIndex = 12;
            this.btnadd.Text = "Add to table";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnremove
            // 
            this.btnremove.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremove.Location = new System.Drawing.Point(656, 207);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(114, 37);
            this.btnremove.TabIndex = 13;
            this.btnremove.Text = "Remove";
            this.btnremove.UseVisualStyleBackColor = true;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // datatable
            // 
            this.datatable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datatable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.datatable.Location = new System.Drawing.Point(304, 250);
            this.datatable.Name = "datatable";
            this.datatable.Size = new System.Drawing.Size(559, 270);
            this.datatable.TabIndex = 14;
            this.datatable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.datatable_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Service Name";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Customer No";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Single Price";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Total";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Month";
            this.Column5.Name = "Column5";
            // 
            // btnreturn
            // 
            this.btnreturn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreturn.Location = new System.Drawing.Point(321, 538);
            this.btnreturn.Name = "btnreturn";
            this.btnreturn.Size = new System.Drawing.Size(102, 32);
            this.btnreturn.TabIndex = 15;
            this.btnreturn.Text = "Return";
            this.btnreturn.UseVisualStyleBackColor = true;
            this.btnreturn.Click += new System.EventHandler(this.btnreturn_Click);
            // 
            // btntotal
            // 
            this.btntotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntotal.Location = new System.Drawing.Point(438, 538);
            this.btntotal.Name = "btntotal";
            this.btntotal.Size = new System.Drawing.Size(98, 32);
            this.btntotal.TabIndex = 16;
            this.btntotal.Text = "Total";
            this.btntotal.UseVisualStyleBackColor = true;
            this.btntotal.Click += new System.EventHandler(this.btntotal_Click);
            // 
            // lblmonthytotal
            // 
            this.lblmonthytotal.AutoSize = true;
            this.lblmonthytotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmonthytotal.Location = new System.Drawing.Point(659, 523);
            this.lblmonthytotal.Name = "lblmonthytotal";
            this.lblmonthytotal.Size = new System.Drawing.Size(100, 19);
            this.lblmonthytotal.TabIndex = 17;
            this.lblmonthytotal.Text = "Monthy Total";
            // 
            // lblrm
            // 
            this.lblrm.AutoSize = true;
            this.lblrm.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrm.Location = new System.Drawing.Point(660, 557);
            this.lblrm.Name = "lblrm";
            this.lblrm.Size = new System.Drawing.Size(41, 19);
            this.lblrm.TabIndex = 18;
            this.lblrm.Text = "RM.";
            // 
            // frmtotalpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(897, 596);
            this.Controls.Add(this.lblrm);
            this.Controls.Add(this.lblmonthytotal);
            this.Controls.Add(this.btntotal);
            this.Controls.Add(this.btnreturn);
            this.Controls.Add(this.datatable);
            this.Controls.Add(this.btnremove);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.txtupdown);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.txttotal);
            this.Controls.Add(this.txtprice);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.txtservicename);
            this.Controls.Add(this.lblservicename);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.cmbbox);
            this.Controls.Add(this.lblselect);
            this.Controls.Add(this.lbltitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmtotalpage";
            this.Text = "Total Income";
            ((System.ComponentModel.ISupportInitialize)(this.txtupdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datatable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltitle;
        private System.Windows.Forms.Label lblselect;
        private System.Windows.Forms.ComboBox cmbbox;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Label lblservicename;
        private System.Windows.Forms.TextBox txtservicename;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.NumericUpDown txtupdown;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.DataGridView datatable;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Button btnreturn;
        private System.Windows.Forms.Button btntotal;
        private System.Windows.Forms.Label lblmonthytotal;
        private System.Windows.Forms.Label lblrm;
    }
}