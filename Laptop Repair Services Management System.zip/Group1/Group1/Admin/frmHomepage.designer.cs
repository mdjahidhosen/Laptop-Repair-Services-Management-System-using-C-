﻿namespace Group1
{
    partial class frmhomepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmhomepage));
            this.btnlogout = new System.Windows.Forms.Button();
            this.grouptasks = new System.Windows.Forms.GroupBox();
            this.btnincome = new System.Windows.Forms.Button();
            this.btnservice = new System.Windows.Forms.Button();
            this.btnreciption = new System.Windows.Forms.Button();
            this.btntech = new System.Windows.Forms.Button();
            this.lblidentity = new System.Windows.Forms.Label();
            this.lblhomepage = new System.Windows.Forms.Label();
            this.grouptasks.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnlogout
            // 
            this.btnlogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnlogout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogout.Location = new System.Drawing.Point(340, 491);
            this.btnlogout.Name = "btnlogout";
            this.btnlogout.Size = new System.Drawing.Size(128, 39);
            this.btnlogout.TabIndex = 7;
            this.btnlogout.Text = "Log out";
            this.btnlogout.UseVisualStyleBackColor = false;
            this.btnlogout.Click += new System.EventHandler(this.btnlogout_Click);
            // 
            // grouptasks
            // 
            this.grouptasks.Controls.Add(this.btnincome);
            this.grouptasks.Controls.Add(this.btnservice);
            this.grouptasks.Controls.Add(this.btnreciption);
            this.grouptasks.Controls.Add(this.btntech);
            this.grouptasks.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grouptasks.Location = new System.Drawing.Point(237, 118);
            this.grouptasks.Name = "grouptasks";
            this.grouptasks.Size = new System.Drawing.Size(359, 367);
            this.grouptasks.TabIndex = 6;
            this.grouptasks.TabStop = false;
            this.grouptasks.Text = "Tasks";
            // 
            // btnincome
            // 
            this.btnincome.Location = new System.Drawing.Point(54, 267);
            this.btnincome.Name = "btnincome";
            this.btnincome.Size = new System.Drawing.Size(237, 53);
            this.btnincome.TabIndex = 3;
            this.btnincome.Text = "Total income";
            this.btnincome.UseVisualStyleBackColor = true;
            this.btnincome.Click += new System.EventHandler(this.btnincome_Click);
            // 
            // btnservice
            // 
            this.btnservice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnservice.Location = new System.Drawing.Point(54, 193);
            this.btnservice.Name = "btnservice";
            this.btnservice.Size = new System.Drawing.Size(237, 51);
            this.btnservice.TabIndex = 2;
            this.btnservice.Text = "Service Report";
            this.btnservice.UseVisualStyleBackColor = false;
            this.btnservice.Click += new System.EventHandler(this.btnservice_Click);
            // 
            // btnreciption
            // 
            this.btnreciption.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnreciption.Location = new System.Drawing.Point(54, 112);
            this.btnreciption.Name = "btnreciption";
            this.btnreciption.Size = new System.Drawing.Size(237, 47);
            this.btnreciption.TabIndex = 1;
            this.btnreciption.Text = "Register Reciption";
            this.btnreciption.UseVisualStyleBackColor = false;
            this.btnreciption.Click += new System.EventHandler(this.btnreciption_Click);
            // 
            // btntech
            // 
            this.btntech.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btntech.Location = new System.Drawing.Point(54, 39);
            this.btntech.Name = "btntech";
            this.btntech.Size = new System.Drawing.Size(237, 43);
            this.btntech.TabIndex = 0;
            this.btntech.Text = "Register Technician";
            this.btntech.UseVisualStyleBackColor = false;
            this.btntech.Click += new System.EventHandler(this.btntech_Click);
            // 
            // lblidentity
            // 
            this.lblidentity.AutoSize = true;
            this.lblidentity.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidentity.Location = new System.Drawing.Point(257, 69);
            this.lblidentity.Name = "lblidentity";
            this.lblidentity.Size = new System.Drawing.Size(303, 31);
            this.lblidentity.TabIndex = 5;
            this.lblidentity.Text = "Welcome to admin panel";
            // 
            // lblhomepage
            // 
            this.lblhomepage.AutoSize = true;
            this.lblhomepage.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhomepage.Location = new System.Drawing.Point(211, 4);
            this.lblhomepage.Name = "lblhomepage";
            this.lblhomepage.Size = new System.Drawing.Size(411, 55);
            this.lblhomepage.TabIndex = 4;
            this.lblhomepage.Text = "Admin Home Page";
            // 
            // frmhomepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumAquamarine;
            this.ClientSize = new System.Drawing.Size(832, 553);
            this.Controls.Add(this.btnlogout);
            this.Controls.Add(this.grouptasks);
            this.Controls.Add(this.lblidentity);
            this.Controls.Add(this.lblhomepage);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmhomepage";
            this.Text = "Admin Home Page";
            this.grouptasks.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnlogout;
        private System.Windows.Forms.GroupBox grouptasks;
        private System.Windows.Forms.Button btnincome;
        private System.Windows.Forms.Button btnservice;
        private System.Windows.Forms.Button btnreciption;
        private System.Windows.Forms.Button btntech;
        private System.Windows.Forms.Label lblidentity;
        private System.Windows.Forms.Label lblhomepage;
    }
}

