﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;



namespace Group1
{
    internal class RegisterStaff
    {
        private string FirstName;
        private string LastName;
        private string Username;
        private string PhoneNumber;
        private string ICPassport;
        private string BirthDate;
        private string Email;
        private string Address;
        private string Password;
        private string ConfirmPassword;
        static SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public string firstName { get => FirstName; set => FirstName = value; }
        public string lastName { get => LastName; set => LastName = value; }
        public string username { get => Username; set => Username = value; }
        public string phoneNumber { get => PhoneNumber; set => PhoneNumber = value; }
        public string iCPassport { get => ICPassport; set => ICPassport = value; }
        public string birthDate { get => BirthDate; set => BirthDate = value; }
        public string email { get => Email; set => Email = value; }
        public string address { get => Address; set => Address = value; }
        public string password { get => Password; set => Password = value; }
        public string confirmPassword { get => ConfirmPassword; set => ConfirmPassword = value; }

        public RegisterStaff(string f, string l, string u, string phn, string ic, string b, string e, string a, string pass, string conpass)
        {
            FirstName = f;
            LastName = l;
            Username = u;
            PhoneNumber = phn;
            ICPassport = ic;
            BirthDate = b;
            Email = e;
            Address = a;
            Password = pass;
            ConfirmPassword = conpass;

        }

        public RegisterStaff(string u)
        {
            FirstName = u;
        }


        public string Registechnician()
        {
            string status;
            con.Open();

            if ((Password != ConfirmPassword) && (Password != " ") && (ConfirmPassword != " "))
                status = "Password does not match";
            else
            {
                SqlCommand cmd = new SqlCommand("insert into Registration(FirstName,LastName,UserRole,Username,PhoneNumber,ICPassport,BirthDate,Email,Address, Password,ConfirmPassword) values(@firstname,@lastname,'Technician',@username,@phn,@ic,@birth,@email,@address,@pass,@conpass)", con);
                // SqlCommand cmd2 = new SqlCommand("insert into users(username,password,role) values(@uname,@pass,'technician')", con);



                cmd.Parameters.AddWithValue("@firstname", FirstName);
                cmd.Parameters.AddWithValue("@lastname", LastName);
                cmd.Parameters.AddWithValue("@username", Username);
                cmd.Parameters.AddWithValue("@phn", PhoneNumber);
                cmd.Parameters.AddWithValue("@ic", ICPassport);
                cmd.Parameters.AddWithValue("@birth", BirthDate);
                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@address", Address);
                // cmd2.Parameters.AddWithValue("@uname", username);
                cmd.Parameters.AddWithValue("@pass", Password);
                //  cmd2.Parameters.AddWithValue("@pass", password);
                cmd.Parameters.AddWithValue("@conpass", ConfirmPassword);

                //  cmd2.ExecuteNonQuery();
                int i = cmd.ExecuteNonQuery();
                if (i != 0)
                    status = "Registration Successful";
                else
                    status = "Unable to Register";

            }

            con.Close();
            return status;

        }

        //create registration method for receptionist
        public string RegisterReceptionist()
        {
            string status;
            con.Open();

            if ((Password != ConfirmPassword) && (Password != " ") && (ConfirmPassword != " "))
                status = "Password does not match";
            else
            {
                SqlCommand cmd = new SqlCommand("insert into Registration(FirstName,LastName,UserRole,Username,PhoneNumber,ICPassport,BirthDate,Email,Address, Password,ConfirmPassword) values(@firstname,@lastname,'Receptionist',@username,@phn,@ic,@birth,@email,@address,@pass,@conpass)", con);
                //  SqlCommand cmd2 = new SqlCommand("insert into users(username,password,role) values(@uname,@pass,'Receptionist')", con);



                cmd.Parameters.AddWithValue("@firstname", FirstName);
                cmd.Parameters.AddWithValue("@lastname", LastName);
                cmd.Parameters.AddWithValue("@username", Username);
                cmd.Parameters.AddWithValue("@phn", PhoneNumber);
                cmd.Parameters.AddWithValue("@ic", ICPassport);
                cmd.Parameters.AddWithValue("@birth", BirthDate);
                cmd.Parameters.AddWithValue("@email", Email);
                cmd.Parameters.AddWithValue("@address", Address);
                //  cmd2.Parameters.AddWithValue("@uname", username);
                cmd.Parameters.AddWithValue("@pass", Password);
                //  cmd2.Parameters.AddWithValue("@pass", password);
                cmd.Parameters.AddWithValue("@conpass", ConfirmPassword);


                // cmd2.ExecuteNonQuery();
                int i = cmd.ExecuteNonQuery();
                if (i != 0)
                    status = "Registration Successful";
                else
                    status = "Unable to Register";

            }

            con.Close();
            return status;

        }

 }   }
