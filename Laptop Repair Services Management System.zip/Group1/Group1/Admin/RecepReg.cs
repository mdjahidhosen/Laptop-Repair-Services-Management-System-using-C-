﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmreceptionpage : Form
    {
        public frmreceptionpage()
        {
            InitializeComponent();
        }


        private void Username_Enter(object sender, EventArgs e)
        {
            if (txtuser.Text == "Write username")
            {
                txtuser.Text = "";
                txtuser.ForeColor = Color.Black;
            }
        }

        private void Username_leave(object sender, EventArgs e)
        {
            if (txtuser.Text == "Write username")
            {
                txtuser.Text = "";
                txtuser.ForeColor = Color.Black;
            }
        }

        private void firstName_Enter(object sender, EventArgs e)
        {
            if (txtNamefull.Text == "First Name")
            {
                txtNamefull.Text = "";
                txtNamefull.ForeColor = Color.Black;
            }
        }

        private void firstName_leave(object sender, EventArgs e)
        {
            if (txtNamefull.Text == "First Name")
            {
                txtNamefull.Text = "";
                txtNamefull.ForeColor = Color.Black;
            }
        }

        private void lastName_Enter(object sender, EventArgs e)
        {
            if (txtLastName.Text == "Last Name")
            {
                txtLastName.Text = "";
                txtLastName.ForeColor = Color.Black;
            }
        }

        private void lastName_leave(object sender, EventArgs e)
        {
            if (txtLastName.Text == "Last Name")
            {
                txtLastName.Text = "";
                txtLastName.ForeColor = Color.Black;
            }
        }

        private void address_Enter(object sender, EventArgs e)
        {
            if (txtaddress.Text == "Write Address")
            {
                txtaddress.Text = "";
                txtaddress.ForeColor = Color.Black;
            }
        }

        private void address_leave(object sender, EventArgs e)
        {
            if (txtaddress.Text == "Write Address")
            {
                txtaddress.Text = "";
                txtaddress.ForeColor = Color.Black;
            }
        }

        private void email_Enter(object sender, EventArgs e)
        {
            if (txtgmail.Text == "Write Address")
            {
                txtgmail.Text = "";
                txtgmail.ForeColor = Color.Black;
            }
        }

        private void email_leave(object sender, EventArgs e)
        {
            if (txtgmail.Text == "Write Address")
            {
                txtgmail.Text = "";
                txtgmail.ForeColor = Color.Black;
            }
        }

        private void phone_Enter(object sender, EventArgs e)
        {
            if (txtphoneno.Text == "Write Phone No")
            {
                txtphoneno.Text = "";
                txtphoneno.ForeColor = Color.Black;
            }
        }
        private void phone_leave(object sender, EventArgs e)
        {
            if (txtphoneno.Text == "Write Phone No")
            {
                txtphoneno.Text = "";
                txtphoneno.ForeColor = Color.Black;
            }
        }

        private void iC_Enter(object sender, EventArgs e)
        {
            if (txticno.Text == "Write IC No")
            {
                txticno.Text = "";
                txticno.ForeColor = Color.Black;
            }
        }

        private void iC_leave(object sender, EventArgs e)
        {
            if (txticno.Text == "Write IC No")
            {
                txticno.Text = "";
                txticno.ForeColor = Color.Black;
            }
        }

        private void password_Enter(object sender, EventArgs e)
        {
            if (txtpass.Text == "Write Password")
            {
                txtpass.Text = "";
                txtpass.ForeColor = Color.Black;
            }
        }

        private void password_leave(object sender, EventArgs e)
        {
            if (txtpass.Text == "Write Password")
            {
                txtpass.Text = "";
                txtpass.ForeColor = Color.Black;
            }
        }


        private void confirmpass_Enter(object sender, EventArgs e)
        {
            if (txtconfirmpass.Text == "Write Confirm Password")
            {
                txtconfirmpass.Text = "";
                txtconfirmpass.ForeColor = Color.Black;
            }
        }

        private void confirmpass_leave(object sender, EventArgs e)
        {
            if (txtconfirmpass.Text == "Write Confirm Password")
            {
                txtconfirmpass.Text = "";
                txtconfirmpass.ForeColor = Color.Black;
            }
        }


        private void date_Enter(object sender, EventArgs e)
        {
            if (datetm.Text == "Write Birth date")
            {
                datetm.Text = "";
                datetm.ForeColor = Color.Black;
            }
        }

        private void date_leave(object sender, EventArgs e)
        {
            if (datetm.Text == "Write Birth date")
            {
                datetm.Text = "";
                datetm.ForeColor = Color.Black;
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterStaff obj1 = new RegisterStaff(txtNamefull.Text, txtLastName.Text, txtuser.Text, txtphoneno.Text, txticno.Text, datetm.Text, txtgmail.Text, txtaddress.Text, txtpass.Text, txtconfirmpass.Text);
            MessageBox.Show(obj1.RegisterReceptionist());
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnbk_Click(object sender, EventArgs e)
        {
            frmhomepage backlogin = new frmhomepage();
            backlogin.ShowDialog();
        }
    }
}
