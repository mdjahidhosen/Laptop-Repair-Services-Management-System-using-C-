﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataSet = System.Data.DataSet;

namespace Group1
{
    public partial class frmtotalpage : Form
    {
        viewService fn = new viewService();
        string query;

        string Servicedetails = "{0,-20}{1,-30}{2,-20}{3,-20}{4,-20}{5,-20}{6,-20}";

        public frmtotalpage()
        {
            InitializeComponent();
        }

        private void cmbbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox.Items.Clear();
            String Month = cmbbox.Text;
            query = "select ServiceName from Servicedetails where Month = '" + Month + "'";
            DataSet ds = fn.getData(query);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBox.Items.Add(ds.Tables[0].Rows[i][0].ToString());

            }
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtupdown.ResetText();
            txttotal.Clear();

            string text = listBox.GetItemText(listBox.SelectedItem);

            txtservicename.Text = text;
            query = "select Price from Servicedetails where ServiceName ='" + text + "'";
            DataSet ds = fn.getData(query);

            try
            {
                txtprice.Text = ds.Tables[0].Rows[0][0].ToString();
            }
            catch { }
        }

        private void txtupdown_ValueChanged(object sender, EventArgs e)
        {
            Int64 quan = Int64.Parse(txtupdown.Value.ToString());
            Int64 Price = Int64.Parse(txtprice.Text);
            txttotal.Text = (quan * Price).ToString();
        }
        protected int n, Total = 0;
        int amount;

        private void btnremove_Click(object sender, EventArgs e)
        {
            try
            {
                datatable.Rows.RemoveAt(this.datatable.SelectedRows[0].Index);
            }
            catch
            {

            }
            Total -= amount;
            lblrm.Text = "RM. " + Total;
        }

        private void datatable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                amount = int.Parse(datatable.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch
            {

            }
        }

        private void btnreturn_Click(object sender, EventArgs e)
        {
            frmhomepage admin_home = new frmhomepage();
            admin_home.ShowDialog();
        }

        private void btntotal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total Monthly income", txttotal.Text);
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(txttotal.Text) != 0 && txttotal.Text != "")
                {
                    n = datatable.Rows.Add();
                    datatable.Rows[n].Cells[0].Value = txtservicename.Text;
                    datatable.Rows[n].Cells[1].Value = txtupdown.Text;
                    datatable.Rows[n].Cells[2].Value = txtprice.Text;
                    datatable.Rows[n].Cells[3].Value = txttotal.Text;
                    datatable.Rows[n].Cells[4].Value = cmbbox.Text;


                    Total = Total + int.Parse(txttotal.Text);
                    lblrm.Text = "RM. " + Total;
                }
                else
                {
                    MessageBox.Show("Minimum Quantity need to be 1", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch
            {
                MessageBox.Show("Invalid Input");
            }
        }

        
    }
}
