﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmtechpage : Form
    {
        public frmtechpage()
        {
            InitializeComponent();
        }


        private void username_Enter(object sender, EventArgs e)
        {
            if (txtusername.Text == "Write username")
            {
                txtusername.Text = "";
                txtusername.ForeColor = Color.Black;
            }
        }

        private void username_leave(object sender, EventArgs e)
        {
            if (txtusername.Text == "Write username")
            {
                txtusername.Text = "";
                txtusername.ForeColor = Color.Black;
            }
        }


        private void FirstName_Enter(object sender, EventArgs e)
        {
            if (txtname.Text == "First Name")
            {
                txtname.Text = "";
                txtname.ForeColor = Color.Black;
            }
        }

        private void FirstName_leave(object sender, EventArgs e)
        {
            if (txtname.Text == "First Name")
            {
                txtname.Text = "";
                txtname.ForeColor = Color.Black;
            }
        }

        private void LastName_Enter(object sender, EventArgs e)
        {
            if (txtlastname.Text == "Last Name")
            {
                txtlastname.Text = "";
                txtlastname.ForeColor = Color.Black;
            }
        }

        private void LastName_leave(object sender, EventArgs e)
        {
            if (txtlastname.Text == "Last Name")
            {
                txtlastname.Text = "";
                txtlastname.ForeColor = Color.Black;
            }
        }

        private void Address_Enter(object sender, EventArgs e)
        {
            if (txtcity.Text == "Write Address")
            {
                txtcity.Text = "";
                txtcity.ForeColor = Color.Black;
            }
        }

        private void Address_leave(object sender, EventArgs e)
        {
            if (txtcity.Text == "Write Address")
            {
                txtcity.Text = "";
                txtcity.ForeColor = Color.Black;
            }
        }

        private void Email_Enter(object sender, EventArgs e)
        {
            if (txtemail.Text == "Write Address")
            {
                txtemail.Text = "";
                txtemail.ForeColor = Color.Black;
            }
        }

        private void Email_leave(object sender, EventArgs e)
        {
            if (txtemail.Text == "Write Address")
            {
                txtemail.Text = "";
                txtemail.ForeColor = Color.Black;
            }
        }

        private void Phone_Enter(object sender, EventArgs e)
        {
            if (txtphone.Text == "Write Phone No")
            {
                txtphone.Text = "";
                txtphone.ForeColor = Color.Black;
            }
        }
        private void Phone_leave(object sender, EventArgs e)
        {
            if (txtphone.Text == "Write Phone No")
            {
                txtphone.Text = "";
                txtphone.ForeColor = Color.Black;
            }
        }

        private void IC_Enter(object sender, EventArgs e)
        {
            if (txtic.Text == "Write IC No")
            {
                txtic.Text = "";
                txtic.ForeColor = Color.Black;
            }
        }

        private void IC_leave(object sender, EventArgs e)
        {
            if (txtic.Text == "Write IC No")
            {
                txtic.Text = "";
                txtic.ForeColor = Color.Black;
            }
        }

        private void Password_Enter(object sender, EventArgs e)
        {
            if (txtpassword.Text == "Write Password")
            {
                txtpassword.Text = "";
                txtpassword.ForeColor = Color.Black;
            }
        }

        private void Password_leave(object sender, EventArgs e)
        {
            if (txtpassword.Text == "Write Password")
            {
                txtpassword.Text = "";
                txtpassword.ForeColor = Color.Black;
            }
        }

        private void Confirmpass_Enter(object sender, EventArgs e)
        {
            if (txtconfirm.Text == "Write Confirm Password")
            {
                txtconfirm.Text = "";
                txtconfirm.ForeColor = Color.Black;
            }
        }

        private void Confirmpass_leave(object sender, EventArgs e)
        {
            if (txtconfirm.Text == "Write Confirm Password")
            {
                txtconfirm.Text = "";
                txtconfirm.ForeColor = Color.Black;
            }
        }

        private void Date_Enter(object sender, EventArgs e)
        {
            if (datetime.Text == "Write Birth date")
            {
                datetime.Text = "";
                datetime.ForeColor = Color.Black;
            }
        }

        private void Date_leave(object sender, EventArgs e)
        {
            if (datetime.Text == "Write Birth date")
            {
                datetime.Text = "";
                datetime.ForeColor = Color.Black;
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            RegisterStaff obj1 = new RegisterStaff(txtname.Text, txtlastname.Text, txtusername.Text, txtphone.Text, txtic.Text, datetime.Text, txtemail.Text, txtcity.Text, txtpassword.Text, txtconfirm.Text);
            MessageBox.Show(obj1.Registechnician());
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            frmhomepage backlogin = new frmhomepage();
            backlogin.ShowDialog();
        }
    }
}
