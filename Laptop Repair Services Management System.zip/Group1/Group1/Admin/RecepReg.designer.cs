﻿namespace Group1
{
    partial class frmreceptionpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmreceptionpage));
            this.btnbk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.datetm = new System.Windows.Forms.DateTimePicker();
            this.txtconfirmpass = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.txticno = new System.Windows.Forms.TextBox();
            this.txtphoneno = new System.Windows.Forms.TextBox();
            this.lblbirthdate = new System.Windows.Forms.Label();
            this.lblconfirmpassword = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.lblicno = new System.Windows.Forms.Label();
            this.lblphoneno = new System.Windows.Forms.Label();
            this.txtgmail = new System.Windows.Forms.TextBox();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtNamefull = new System.Windows.Forms.TextBox();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.lblgmail = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblNamefull = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.lbltitle = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnbk
            // 
            this.btnbk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnbk.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbk.Location = new System.Drawing.Point(85, 510);
            this.btnbk.Name = "btnbk";
            this.btnbk.Size = new System.Drawing.Size(92, 35);
            this.btnbk.TabIndex = 47;
            this.btnbk.Text = "Back";
            this.btnbk.UseVisualStyleBackColor = false;
            this.btnbk.Click += new System.EventHandler(this.btnbk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(689, 510);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(94, 35);
            this.btnCancel.TabIndex = 46;
            this.btnCancel.Text = "Exit";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRegister.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.Location = new System.Drawing.Point(356, 436);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(127, 40);
            this.btnRegister.TabIndex = 45;
            this.btnRegister.Text = "Update";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // datetm
            // 
            this.datetm.CustomFormat = "MM-dd-yyyy";
            this.datetm.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.datetm.Location = new System.Drawing.Point(571, 378);
            this.datetm.Name = "datetm";
            this.datetm.Size = new System.Drawing.Size(184, 20);
            this.datetm.TabIndex = 44;
            // 
            // txtconfirmpass
            // 
            this.txtconfirmpass.Location = new System.Drawing.Point(571, 303);
            this.txtconfirmpass.Multiline = true;
            this.txtconfirmpass.Name = "txtconfirmpass";
            this.txtconfirmpass.Size = new System.Drawing.Size(184, 32);
            this.txtconfirmpass.TabIndex = 43;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(571, 241);
            this.txtpass.Multiline = true;
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(184, 32);
            this.txtpass.TabIndex = 42;
            // 
            // txticno
            // 
            this.txticno.Location = new System.Drawing.Point(571, 187);
            this.txticno.Multiline = true;
            this.txticno.Name = "txticno";
            this.txticno.Size = new System.Drawing.Size(184, 29);
            this.txticno.TabIndex = 41;
            // 
            // txtphoneno
            // 
            this.txtphoneno.Location = new System.Drawing.Point(571, 136);
            this.txtphoneno.Multiline = true;
            this.txtphoneno.Name = "txtphoneno";
            this.txtphoneno.Size = new System.Drawing.Size(184, 33);
            this.txtphoneno.TabIndex = 40;
            // 
            // lblbirthdate
            // 
            this.lblbirthdate.AutoSize = true;
            this.lblbirthdate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbirthdate.Location = new System.Drawing.Point(452, 380);
            this.lblbirthdate.Name = "lblbirthdate";
            this.lblbirthdate.Size = new System.Drawing.Size(80, 19);
            this.lblbirthdate.TabIndex = 39;
            this.lblbirthdate.Text = "Birth Date";
            // 
            // lblconfirmpassword
            // 
            this.lblconfirmpassword.AutoSize = true;
            this.lblconfirmpassword.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconfirmpassword.Location = new System.Drawing.Point(423, 316);
            this.lblconfirmpassword.Name = "lblconfirmpassword";
            this.lblconfirmpassword.Size = new System.Drawing.Size(130, 19);
            this.lblconfirmpassword.TabIndex = 38;
            this.lblconfirmpassword.Text = "Confirm Password";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpass.Location = new System.Drawing.Point(437, 254);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(72, 19);
            this.lblpass.TabIndex = 37;
            this.lblpass.Text = "Password";
            // 
            // lblicno
            // 
            this.lblicno.AutoSize = true;
            this.lblicno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblicno.Location = new System.Drawing.Point(437, 197);
            this.lblicno.Name = "lblicno";
            this.lblicno.Size = new System.Drawing.Size(84, 19);
            this.lblicno.TabIndex = 36;
            this.lblicno.Text = "ICPassport";
            // 
            // lblphoneno
            // 
            this.lblphoneno.AutoSize = true;
            this.lblphoneno.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphoneno.Location = new System.Drawing.Point(437, 141);
            this.lblphoneno.Name = "lblphoneno";
            this.lblphoneno.Size = new System.Drawing.Size(104, 19);
            this.lblphoneno.TabIndex = 35;
            this.lblphoneno.Text = "Phone number";
            // 
            // txtgmail
            // 
            this.txtgmail.Location = new System.Drawing.Point(177, 372);
            this.txtgmail.Multiline = true;
            this.txtgmail.Name = "txtgmail";
            this.txtgmail.Size = new System.Drawing.Size(192, 30);
            this.txtgmail.TabIndex = 34;
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(177, 303);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(192, 32);
            this.txtaddress.TabIndex = 33;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(177, 241);
            this.txtLastName.Multiline = true;
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(192, 32);
            this.txtLastName.TabIndex = 32;
            // 
            // txtNamefull
            // 
            this.txtNamefull.Location = new System.Drawing.Point(177, 187);
            this.txtNamefull.Multiline = true;
            this.txtNamefull.Name = "txtNamefull";
            this.txtNamefull.Size = new System.Drawing.Size(192, 29);
            this.txtNamefull.TabIndex = 31;
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(177, 135);
            this.txtuser.Multiline = true;
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(192, 34);
            this.txtuser.TabIndex = 30;
            // 
            // lblgmail
            // 
            this.lblgmail.AutoSize = true;
            this.lblgmail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgmail.Location = new System.Drawing.Point(81, 383);
            this.lblgmail.Name = "lblgmail";
            this.lblgmail.Size = new System.Drawing.Size(47, 19);
            this.lblgmail.TabIndex = 29;
            this.lblgmail.Text = "Email";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.Location = new System.Drawing.Point(81, 316);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(64, 19);
            this.lbladdress.TabIndex = 28;
            this.lbladdress.Text = "Address";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(81, 254);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(83, 19);
            this.lblLastName.TabIndex = 27;
            this.lblLastName.Text = "Last Name";
            // 
            // lblNamefull
            // 
            this.lblNamefull.AutoSize = true;
            this.lblNamefull.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNamefull.Location = new System.Drawing.Point(81, 197);
            this.lblNamefull.Name = "lblNamefull";
            this.lblNamefull.Size = new System.Drawing.Size(84, 19);
            this.lblNamefull.TabIndex = 26;
            this.lblNamefull.Text = "First Name";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.Location = new System.Drawing.Point(81, 136);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(81, 19);
            this.lbluser.TabIndex = 25;
            this.lbluser.Text = "UserName";
            // 
            // lbltitle
            // 
            this.lbltitle.AutoSize = true;
            this.lbltitle.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitle.Location = new System.Drawing.Point(146, 15);
            this.lbltitle.Name = "lbltitle";
            this.lbltitle.Size = new System.Drawing.Size(540, 55);
            this.lbltitle.TabIndex = 24;
            this.lbltitle.Text = "Receptionist Registration";
            // 
            // frmreceptionpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(865, 561);
            this.Controls.Add(this.btnbk);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.datetm);
            this.Controls.Add(this.txtconfirmpass);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txticno);
            this.Controls.Add(this.txtphoneno);
            this.Controls.Add(this.lblbirthdate);
            this.Controls.Add(this.lblconfirmpassword);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblicno);
            this.Controls.Add(this.lblphoneno);
            this.Controls.Add(this.txtgmail);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtNamefull);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.lblgmail);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblNamefull);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.lbltitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmreceptionpage";
            this.Text = "Receptionist Registration";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnbk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.DateTimePicker datetm;
        private System.Windows.Forms.TextBox txtconfirmpass;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.TextBox txticno;
        private System.Windows.Forms.TextBox txtphoneno;
        private System.Windows.Forms.Label lblbirthdate;
        private System.Windows.Forms.Label lblconfirmpassword;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label lblicno;
        private System.Windows.Forms.Label lblphoneno;
        private System.Windows.Forms.TextBox txtgmail;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtNamefull;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.Label lblgmail;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblNamefull;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label lbltitle;
    }
}