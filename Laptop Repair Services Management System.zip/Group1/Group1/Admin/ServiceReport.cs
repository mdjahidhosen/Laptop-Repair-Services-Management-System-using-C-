﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmservicepage : Form
    {
        viewService fn = new viewService();
        string Servicedetails;

        public frmservicepage()
        {
            InitializeComponent();
        }

        private void cmbboxmonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxItems.Items.Clear();
            String Month = cmbboxmonth.Text;
            Servicedetails = "select ServiceName from Servicedetails where Month = '" + Month + "'";
            DataSet ds = fn.getData(Servicedetails);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBoxItems.Items.Add(ds.Tables[0].Rows[i][0].ToString());

            }
        }

        private void listBoxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            string text = listBoxItems.GetItemText(listBoxItems.SelectedItem);


            Servicedetails = "select Price from Servicedetails where ServiceName ='" + text + "'";
            DataSet ds = fn.getData(Servicedetails);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmhomepage backlogin = new frmhomepage();
            backlogin.ShowDialog();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            listBoxItems.Items.Clear();
            String Month = cmbboxmonth.Text;
            Servicedetails = "select ServiceName from Servicedetails where Month = '" + Month + "' and ServiceName like '" + txtsearch.Text + "%'";
            DataSet ds = fn.getData(Servicedetails);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                listBoxItems.Items.Add(ds.Tables[0].Rows[i][0].ToString());

            }
        }
    }
}
