﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Windows.Forms;

namespace Group1
{
    internal class AllUsers
    {
        private string username, password;
        

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public AllUsers(string user,string pass)
        {
            username = user;
            password = pass;
        }

        public static bool IsEmpty(params string[] arguments)
        {
            if (arguments.Length == 0) return true;
            return arguments.Any(p => string.IsNullOrEmpty(p));
        }

        public string userlogin()
        {
            string status = null;
            conn.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT count(*) FROM Registration WHERE Username = '" + username + "' AND Password = '" + password + "'", conn); 
                int count = Convert.ToInt32(cmd.ExecuteScalar().ToString());

                if (count > 0) //check for the matching data
                {
                    status = "Successfully Login";
                    SqlCommand cmd1 = new SqlCommand("SELECT UserRole FROM Registration WHERE Username = '" + username + "' AND Password = '" + password + "'", conn);
                    string userrole = cmd1.ExecuteScalar().ToString();

                    if (userrole == "Admin")
                    {
                        frmhomepage AD = new frmhomepage();
                        AD.Show();
                    }
                    else if (userrole == "Receptionist")
                    {
                        frmReceptionist RE = new frmReceptionist();
                        RE.Show();
                    }
                    else if (userrole == "Technician")
                    {
                        TechnicianMenu TC = new TechnicianMenu();
                        TC.Show();
                    }
                    else if (userrole == "Customer")
                    {
                        frmCustHome CS = new frmCustHome();
                        CS.Show();
                    }
                    else
                    {
                        status = "No recorded for role";
                    }
                    
                }
                else
                {
                    status = "Invalid username or password";
                }
            }
            catch
            {
                status = "Database Connection Error";
            }
            finally
            {
                conn.Close();
                
            }

            return status;
        }
    }
}