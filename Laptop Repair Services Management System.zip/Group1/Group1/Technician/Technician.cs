﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Group1
{
    

    internal class Technician
    {
        private string tablename;

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public Technician(string tbname)
        {
            tablename = tbname;
        }
        public DataTable Loaddbtablecond(string attrib, string cond) 
        {
            string query = "SELECT " + attrib + " FROM " + tablename + " WHERE " + cond;
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table; //return the datatable with condition
        }

        public DataTable Loaddbtable(string attrib)
        {
            string query = "SELECT " + attrib + " FROM " + tablename;
            SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table; //return the datatable without condition
        }

        public bool Updatedb(string set, string cond)
        {
            try
            {
                conn.Open();
                string query = "UPDATE " + tablename + " SET " + set + " WHERE " + cond;
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
