﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Group1
{
    public partial class UserLogin : Form
    {
        public static string LoginUsername, LoginPassword;

        public UserLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e) //login to the form
        {
            string status1;


            if (!AllUsers.IsEmpty(txtUsername.Text, txtPassword.Text)) //To validate whether the textbox is empty or not
            {
                AllUsers user = new AllUsers(txtUsername.Text, txtPassword.Text); 
                status1 = user.userlogin(); 
                if (status1 != "Successfully Login")
                {
                    MessageBox.Show(status1);
                    cleardata();
                }
                else
                {
                    LoginUsername = txtUsername.Text;
                    LoginPassword = txtPassword.Text;
                    cleardata();
                    this.Hide();
                }
            }
            else
            {
                MessageBox.Show("Please enter username or password", "Input Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cleardata();
            }
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(this, new EventArgs());
            }
            else if (e.KeyCode == Keys.Escape)
            {
                exitprogram();
            }
            else
            {
                this.Show();
            }
        }

        private void btnCLear_Click(object sender, EventArgs e)
        {
            cleardata();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            exitprogram();
        }
        private void cleardata()
        {
            txtUsername.Text = null;
            txtPassword.Text = null;
            txtUsername.Focus();
        }

        private void exitprogram()
        {
            DialogResult result = MessageBox.Show("Exit the program", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                this.Show();
            }
        }
    }
}
