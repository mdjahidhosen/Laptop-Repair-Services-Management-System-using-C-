﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class TechnicianUpdateProfile : Form
    {
        string Username;
        string attr = null;
        string set = null;
        string condition = null;
        public static string tablename = "Registration";

        Technician TCUP = new Technician(tablename);

        public TechnicianUpdateProfile()
        {
            InitializeComponent();
            Username = UserLogin.LoginUsername; //to get the username as condition when login to the form
        }

        private void UpdateProfile_Load(object sender, EventArgs e)
        {
            loaddbtable();
        }

        private void loaddbtable() //load the data table into grid view
        {
            attr = "*";
            condition = "Username = '" + Username + "'";
            dataGridView1.DataSource = TCUP.Loaddbtablecond(attr,condition);
        }

        private void dataGridView1_Click(object sender, EventArgs e) //the selected data from grid view will be display on the textbox
        {
            txtFirstName.Text = dataGridView1.CurrentRow.Cells["FirstName"].Value.ToString();
            txtLastName.Text = dataGridView1.CurrentRow.Cells["LastName"].Value.ToString();
            txtUsername.Text = dataGridView1.CurrentRow.Cells["Username"].Value.ToString();
            txtPhoneNumber.Text = dataGridView1.CurrentRow.Cells["PhoneNumber"].Value.ToString();
            txtIcOrPassportNumber.Text = dataGridView1.CurrentRow.Cells["ICPassport"].Value.ToString();
            txtEmailAddress.Text = dataGridView1.CurrentRow.Cells["Email"].Value.ToString();
            txtAddress.Text = dataGridView1.CurrentRow.Cells["Address"].Value.ToString();
            dtpBirthDate.Value = DateTime.Parse(dataGridView1.CurrentRow.Cells["BirthDate"].Value.ToString());
            txtPassword.Text = dataGridView1.CurrentRow.Cells["Password"].Value.ToString();
            txtConfirmPassword.Text = dataGridView1.CurrentRow.Cells["ConfirmPassword"].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e) //Update all the data with validation
        {
            string datetime = dtpBirthDate.Value.ToString("MM-dd-yyyy");

            set = "FirstName = '" + txtFirstName.Text + "', LastName = '" + txtLastName.Text + "', Username = '" + txtUsername.Text + "', " +
                "PhoneNumber = '" + txtPhoneNumber.Text + "', ICPassport = '" + txtIcOrPassportNumber.Text + "', Email = '" + txtEmailAddress.Text + "', " +
                "Address = '" + txtAddress.Text + "', BirthDate = '" + datetime + "', Password = '" + txtPassword.Text + "', ConfirmPassword = '" + txtConfirmPassword.Text + "'";

            condition = "Username = '" + Username + "'";

            Regex VF = new Regex("^[a-zA-Z ]{1,15}$");
            Regex VL = new Regex("^[a-zA-Z ]{1,15}$");
            Regex VP = new Regex("^[0-9 ]{1,15}$");
            Regex VI = new Regex("^[0-9 ]{1,15}$");
            Regex VE = new Regex("^[a-zA-Z0-9 ]{1,15}@[a-zA-Z ]{1,15}.[a-zA-Z ]{1,15}$");

            bool requestVF = VF.IsMatch(txtFirstName.Text);
            bool requestVL = VL.IsMatch(txtLastName.Text);
            bool requestVP = VP.IsMatch(txtPhoneNumber.Text);
            bool requestVI = VI.IsMatch(txtIcOrPassportNumber.Text);
            bool requestVE = VE.IsMatch(txtEmailAddress.Text);

            if (!AllUsers.IsEmpty(txtFirstName.Text, txtLastName.Text, txtUsername.Text, txtPhoneNumber.Text, txtIcOrPassportNumber.Text, txtEmailAddress.Text, txtAddress.Text, txtPassword.Text)) //To validate whether the textbox is empty or not
            {
                if (txtPassword.Text == txtConfirmPassword.Text) //Check whether the value is same or not
                {
                    if (requestVF && requestVL && requestVP && requestVI && requestVE) //To check the request is true or false
                    {
                        bool request = TCUP.Updatedb(set, condition);
                        if (request)
                        {
                            MessageBox.Show("Successfully Updated", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Database Connection Error", "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        loaddbtable();
                    }
                    else
                    {
                        MessageBox.Show("Please only input alphabet in First Name & Last Name,only number in Phone Number & IC Passport, and Email address with @ and .", "Input Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Password must be match with confirm password", "Input Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please do not leave blank", "Input Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnBack_Click(object sender, EventArgs e) //return to the menu form
        {
            TechnicianMenu TMUP = new TechnicianMenu();
            this.Close();
            TMUP.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Exit the program", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                this.Show();
            }
        }
    }
}
