﻿namespace Group1
{
    partial class TechnicianServiceManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TechnicianServiceManagement));
            this.lblServiceManagement = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.gbFilter = new System.Windows.Forms.GroupBox();
            this.btnRepairing = new System.Windows.Forms.Button();
            this.btnFailed = new System.Windows.Forms.Button();
            this.btnIncomplete = new System.Windows.Forms.Button();
            this.btnCompleted = new System.Windows.Forms.Button();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.gbSelected = new System.Windows.Forms.GroupBox();
            this.txtServiceType = new System.Windows.Forms.TextBox();
            this.lblServiceType = new System.Windows.Forms.Label();
            this.txtService = new System.Windows.Forms.TextBox();
            this.lblService = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtOrderID1 = new System.Windows.Forms.TextBox();
            this.lblOrderID1 = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnUpdateAll = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtDescriiption = new System.Windows.Forms.TextBox();
            this.dtpCollectionDate = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblCollectionDate = new System.Windows.Forms.Label();
            this.lblRepairStatus = new System.Windows.Forms.Label();
            this.btnDeleteAll = new System.Windows.Forms.Button();
            this.gbFilter.SuspendLayout();
            this.gbSelected.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblServiceManagement
            // 
            this.lblServiceManagement.AutoSize = true;
            this.lblServiceManagement.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceManagement.Location = new System.Drawing.Point(249, 9);
            this.lblServiceManagement.Name = "lblServiceManagement";
            this.lblServiceManagement.Size = new System.Drawing.Size(452, 55);
            this.lblServiceManagement.TabIndex = 53;
            this.lblServiceManagement.Text = "Service Management";
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.LightGray;
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(29, 567);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(138, 35);
            this.btnBack.TabIndex = 51;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // gbFilter
            // 
            this.gbFilter.Controls.Add(this.btnRepairing);
            this.gbFilter.Controls.Add(this.btnFailed);
            this.gbFilter.Controls.Add(this.btnIncomplete);
            this.gbFilter.Controls.Add(this.btnCompleted);
            this.gbFilter.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFilter.Location = new System.Drawing.Point(477, 384);
            this.gbFilter.Name = "gbFilter";
            this.gbFilter.Size = new System.Drawing.Size(505, 56);
            this.gbFilter.TabIndex = 50;
            this.gbFilter.TabStop = false;
            this.gbFilter.Text = "Filter";
            // 
            // btnRepairing
            // 
            this.btnRepairing.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRepairing.Location = new System.Drawing.Point(25, 19);
            this.btnRepairing.Name = "btnRepairing";
            this.btnRepairing.Size = new System.Drawing.Size(106, 26);
            this.btnRepairing.TabIndex = 30;
            this.btnRepairing.Text = "Repairing";
            this.btnRepairing.UseVisualStyleBackColor = false;
            this.btnRepairing.Click += new System.EventHandler(this.btnRepairing_Click);
            // 
            // btnFailed
            // 
            this.btnFailed.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFailed.Location = new System.Drawing.Point(366, 19);
            this.btnFailed.Name = "btnFailed";
            this.btnFailed.Size = new System.Drawing.Size(106, 26);
            this.btnFailed.TabIndex = 29;
            this.btnFailed.Text = "Failed";
            this.btnFailed.UseVisualStyleBackColor = false;
            this.btnFailed.Click += new System.EventHandler(this.btnFailed_Click);
            // 
            // btnIncomplete
            // 
            this.btnIncomplete.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnIncomplete.Location = new System.Drawing.Point(252, 19);
            this.btnIncomplete.Name = "btnIncomplete";
            this.btnIncomplete.Size = new System.Drawing.Size(106, 26);
            this.btnIncomplete.TabIndex = 28;
            this.btnIncomplete.Text = "Incomplete";
            this.btnIncomplete.UseVisualStyleBackColor = false;
            this.btnIncomplete.Click += new System.EventHandler(this.btnIncompleted_Click);
            // 
            // btnCompleted
            // 
            this.btnCompleted.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCompleted.Location = new System.Drawing.Point(137, 19);
            this.btnCompleted.Name = "btnCompleted";
            this.btnCompleted.Size = new System.Drawing.Size(106, 26);
            this.btnCompleted.TabIndex = 27;
            this.btnCompleted.Text = "Completed";
            this.btnCompleted.UseVisualStyleBackColor = false;
            this.btnCompleted.Click += new System.EventHandler(this.btnCompleted_Click);
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderID.Location = new System.Drawing.Point(376, 72);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(71, 19);
            this.lblOrderID.TabIndex = 45;
            this.lblOrderID.Text = "Order ID";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSearch.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(638, 67);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(81, 26);
            this.btnSearch.TabIndex = 49;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(453, 71);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(167, 20);
            this.txtsearch.TabIndex = 48;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.LightGray;
            this.btnExit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(844, 567);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(138, 35);
            this.btnExit.TabIndex = 47;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // gbSelected
            // 
            this.gbSelected.Controls.Add(this.txtServiceType);
            this.gbSelected.Controls.Add(this.lblServiceType);
            this.gbSelected.Controls.Add(this.txtService);
            this.gbSelected.Controls.Add(this.lblService);
            this.gbSelected.Controls.Add(this.txtUsername);
            this.gbSelected.Controls.Add(this.lblName);
            this.gbSelected.Controls.Add(this.txtOrderID1);
            this.gbSelected.Controls.Add(this.lblOrderID1);
            this.gbSelected.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSelected.Location = new System.Drawing.Point(380, 440);
            this.gbSelected.Name = "gbSelected";
            this.gbSelected.Size = new System.Drawing.Size(601, 112);
            this.gbSelected.TabIndex = 46;
            this.gbSelected.TabStop = false;
            this.gbSelected.Text = "Selected";
            // 
            // txtServiceType
            // 
            this.txtServiceType.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceType.Location = new System.Drawing.Point(371, 63);
            this.txtServiceType.Name = "txtServiceType";
            this.txtServiceType.ReadOnly = true;
            this.txtServiceType.Size = new System.Drawing.Size(167, 22);
            this.txtServiceType.TabIndex = 24;
            // 
            // lblServiceType
            // 
            this.lblServiceType.AutoSize = true;
            this.lblServiceType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceType.Location = new System.Drawing.Point(272, 63);
            this.lblServiceType.Name = "lblServiceType";
            this.lblServiceType.Size = new System.Drawing.Size(96, 19);
            this.lblServiceType.TabIndex = 23;
            this.lblServiceType.Text = "Service Type";
            // 
            // txtService
            // 
            this.txtService.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtService.Location = new System.Drawing.Point(85, 63);
            this.txtService.Name = "txtService";
            this.txtService.ReadOnly = true;
            this.txtService.Size = new System.Drawing.Size(167, 22);
            this.txtService.TabIndex = 22;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblService.Location = new System.Drawing.Point(8, 64);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(59, 19);
            this.lblService.TabIndex = 21;
            this.lblService.Text = "Service";
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.Location = new System.Drawing.Point(371, 24);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.ReadOnly = true;
            this.txtUsername.Size = new System.Drawing.Size(167, 22);
            this.txtUsername.TabIndex = 20;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(272, 25);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(77, 19);
            this.lblName.TabIndex = 19;
            this.lblName.Text = "Username";
            // 
            // txtOrderID1
            // 
            this.txtOrderID1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderID1.Location = new System.Drawing.Point(85, 24);
            this.txtOrderID1.Name = "txtOrderID1";
            this.txtOrderID1.ReadOnly = true;
            this.txtOrderID1.Size = new System.Drawing.Size(167, 22);
            this.txtOrderID1.TabIndex = 18;
            // 
            // lblOrderID1
            // 
            this.lblOrderID1.AutoSize = true;
            this.lblOrderID1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderID1.Location = new System.Drawing.Point(7, 25);
            this.lblOrderID1.Name = "lblOrderID1";
            this.lblOrderID1.Size = new System.Drawing.Size(71, 19);
            this.lblOrderID1.TabIndex = 17;
            this.lblOrderID1.Text = "Order ID";
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnView.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(380, 399);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(81, 26);
            this.btnView.TabIndex = 44;
            this.btnView.Text = "View/Refresh";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(380, 99);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(601, 278);
            this.dataGridView1.TabIndex = 43;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.DarkGray;
            this.btnReset.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(148, 285);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(130, 35);
            this.btnReset.TabIndex = 42;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnUpdateAll
            // 
            this.btnUpdateAll.BackColor = System.Drawing.Color.DarkGray;
            this.btnUpdateAll.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateAll.Location = new System.Drawing.Point(28, 511);
            this.btnUpdateAll.Name = "btnUpdateAll";
            this.btnUpdateAll.Size = new System.Drawing.Size(161, 41);
            this.btnUpdateAll.TabIndex = 41;
            this.btnUpdateAll.Text = "Update All";
            this.btnUpdateAll.UseVisualStyleBackColor = false;
            this.btnUpdateAll.Click += new System.EventHandler(this.btnUpdateAll_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(28, 467);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(330, 19);
            this.checkBox1.TabIndex = 40;
            this.checkBox1.Text = "Please confirm that the details are correct before update";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // txtDescriiption
            // 
            this.txtDescriiption.Location = new System.Drawing.Point(148, 231);
            this.txtDescriiption.Name = "txtDescriiption";
            this.txtDescriiption.Size = new System.Drawing.Size(167, 20);
            this.txtDescriiption.TabIndex = 39;
            // 
            // dtpCollectionDate
            // 
            this.dtpCollectionDate.CustomFormat = "MM-dd-yyyy";
            this.dtpCollectionDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCollectionDate.Location = new System.Drawing.Point(149, 166);
            this.dtpCollectionDate.Name = "dtpCollectionDate";
            this.dtpCollectionDate.Size = new System.Drawing.Size(166, 20);
            this.dtpCollectionDate.TabIndex = 38;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Repairing",
            "Repair Failed",
            "Completed"});
            this.comboBox1.Location = new System.Drawing.Point(149, 100);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(167, 21);
            this.comboBox1.TabIndex = 37;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(24, 230);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(86, 19);
            this.lblDescription.TabIndex = 36;
            this.lblDescription.Text = "Description";
            // 
            // lblCollectionDate
            // 
            this.lblCollectionDate.AutoSize = true;
            this.lblCollectionDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCollectionDate.Location = new System.Drawing.Point(24, 166);
            this.lblCollectionDate.Name = "lblCollectionDate";
            this.lblCollectionDate.Size = new System.Drawing.Size(113, 19);
            this.lblCollectionDate.TabIndex = 35;
            this.lblCollectionDate.Text = "Collection Date";
            // 
            // lblRepairStatus
            // 
            this.lblRepairStatus.AutoSize = true;
            this.lblRepairStatus.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepairStatus.Location = new System.Drawing.Point(25, 99);
            this.lblRepairStatus.Name = "lblRepairStatus";
            this.lblRepairStatus.Size = new System.Drawing.Size(101, 19);
            this.lblRepairStatus.TabIndex = 34;
            this.lblRepairStatus.Text = "Repair Status";
            // 
            // btnDeleteAll
            // 
            this.btnDeleteAll.BackColor = System.Drawing.Color.DarkGray;
            this.btnDeleteAll.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteAll.Location = new System.Drawing.Point(197, 511);
            this.btnDeleteAll.Name = "btnDeleteAll";
            this.btnDeleteAll.Size = new System.Drawing.Size(161, 41);
            this.btnDeleteAll.TabIndex = 54;
            this.btnDeleteAll.Text = "Delete All";
            this.btnDeleteAll.UseVisualStyleBackColor = false;
            this.btnDeleteAll.Click += new System.EventHandler(this.btnDeleteAll_Click);
            // 
            // TechnicianServiceManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSkyBlue;
            this.ClientSize = new System.Drawing.Size(1007, 611);
            this.Controls.Add(this.btnDeleteAll);
            this.Controls.Add(this.lblServiceManagement);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.gbFilter);
            this.Controls.Add(this.lblOrderID);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.gbSelected);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnUpdateAll);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.txtDescriiption);
            this.Controls.Add(this.dtpCollectionDate);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lblCollectionDate);
            this.Controls.Add(this.lblRepairStatus);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TechnicianServiceManagement";
            this.Text = "Service Management";
            this.gbFilter.ResumeLayout(false);
            this.gbSelected.ResumeLayout(false);
            this.gbSelected.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblServiceManagement;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.GroupBox gbFilter;
        private System.Windows.Forms.Button btnRepairing;
        private System.Windows.Forms.Button btnFailed;
        private System.Windows.Forms.Button btnIncomplete;
        private System.Windows.Forms.Button btnCompleted;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox gbSelected;
        private System.Windows.Forms.TextBox txtService;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtOrderID1;
        private System.Windows.Forms.Label lblOrderID1;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnUpdateAll;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtDescriiption;
        private System.Windows.Forms.DateTimePicker dtpCollectionDate;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblCollectionDate;
        private System.Windows.Forms.Label lblRepairStatus;
        private System.Windows.Forms.TextBox txtServiceType;
        private System.Windows.Forms.Label lblServiceType;
        private System.Windows.Forms.Button btnDeleteAll;
    }
}