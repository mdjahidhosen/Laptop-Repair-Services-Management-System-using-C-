﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class TechnicianMenu : Form
    {
        public TechnicianMenu()
        {
            InitializeComponent();
        }

        private void btnServiceManagement_Click(object sender, EventArgs e) //navigate to TechnicianServiceManagement form
        {
            TechnicianServiceManagement SM = new TechnicianServiceManagement();
            SM.Show();
            this.Hide();
        }

        private void btnUpdateProfile_Click(object sender, EventArgs e) //navigate to TechnicianUpdateProfile form
        {
            TechnicianUpdateProfile UP = new TechnicianUpdateProfile();
            UP.Show();
            this.Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e) //return to the login form
        {
            DialogResult result = MessageBox.Show("Logout", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                this.Close();
                UserLogin LG = new UserLogin();
                LG.Show();
            }
            else if (result == DialogResult.No)
            {
                this.Show();
            }
        }

        private void btnExit_Click(object sender, EventArgs e) //close this program
        {
            DialogResult result = MessageBox.Show("Exit the program", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                this.Show();
            }
        }
    }
}
