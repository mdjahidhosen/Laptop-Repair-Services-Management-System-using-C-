﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class TechnicianServiceManagement : Form
    {

        string attr = "OrderID, Username, Service, ServiceType, Status, CollectionDate, Description";
        string set = null;
        string condition = null;
        string key = null;
        public static string tablename = "Services";
        Technician TCSM = new Technician(tablename);

        public TechnicianServiceManagement()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            loaddata();
        }

        private void loaddata() // load the data into gridview
        {
            dataGridView1.DataSource = TCSM.Loaddbtable(attr);
        }

        private void dataGridView1_Click(object sender, EventArgs e) //the selected data from grid view will be display on the textbox
        {
            txtOrderID1.Text = dataGridView1.CurrentRow.Cells["OrderID"].Value.ToString();
            txtUsername.Text = dataGridView1.CurrentRow.Cells["Username"].Value.ToString();
            txtService.Text = dataGridView1.CurrentRow.Cells["Service"].Value.ToString();
            txtServiceType.Text = dataGridView1.CurrentRow.Cells["ServiceType"].Value.ToString();
            txtsearch.Text = null;
        }

        private void btnSearch_Click(object sender, EventArgs e) //using OrderID as condition to search the specific row
        {
            condition = "OrderID = '" + txtsearch.Text + "'";
            dataGridView1.DataSource = TCSM.Loaddbtablecond(attr,condition);
            txtsearch.Text = null;
        }

        private void btnRepairing_Click(object sender, EventArgs e)
        {
            key = "Repairing";
            searchengine(key);
        }

        private void btnCompleted_Click(object sender, EventArgs e)
        {
            key = "Completed";
            searchengine(key);
        }

        private void btnIncompleted_Click(object sender, EventArgs e)
        {
            key = "Incomplete";
            searchengine(key);
        }

        private void btnFailed_Click(object sender, EventArgs e)
        {
            key = "Repair Failed";
            searchengine(key);
        }

        private void searchengine(string keyw) //passing the keyword as conditoin and display filtered data on grid view
        {
            condition = "Status = '" + keyw + "'";
            dataGridView1.DataSource = TCSM.Loaddbtablecond(attr,condition);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            resetinput();
        }

        private void btnUpdateAll_Click(object sender, EventArgs e)
        {
            
            condition = "Username = '" + txtUsername.Text + "'";

            if (checkBox1.Checked)
            {
                if (comboBox1.SelectedIndex != -1)
                {
                    string repairstatus = comboBox1.SelectedItem.ToString();
                    string repaircollectiondate = dtpCollectionDate.Value.ToString("MM-dd-yyyy");
                    string repairdescription = txtDescriiption.Text.ToString();

                    if (comboBox1.SelectedIndex == 0) //selected "repairing" as status
                    {

                        set = "Status = '" + repairstatus + "', Description = '" + repairdescription + "'";

                    }
                    else if (comboBox1.SelectedIndex == 1 || comboBox1.SelectedIndex == 2) //selected "Repair Failed or Completed" as status
                    {
                        if (DateTime.Today > dtpCollectionDate.Value)
                        {
                            MessageBox.Show("Invalid Date", "Selection Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                        else
                        {
                            set = "Status = '" + repairstatus + "', CollectionDate = '" + repaircollectiondate + "', Description = '" + repairdescription + "'";
                        }
                    }

                    bool request = TCSM.Updatedb(set, condition);
                    if (request)
                    {
                        MessageBox.Show("Successfully Updated", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Database Connection Error", "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show("Please Selecet a Status", "Selection Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please tick the checkbox before procceed", "Selection Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            loaddata();
            resetinput();
        }
        private void resetinput()
        {
            comboBox1.Text = null;
            dtpCollectionDate.Text = null;
            txtDescriiption.Text = null;
            checkBox1.Checked = false;
        }

        public void btnBack_Click(object sender, EventArgs e)
        {
            TechnicianMenu TMSM = new TechnicianMenu();
            this.Close();
            TMSM.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Exit the program", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
            else if (result == DialogResult.No)
            {
                this.Show();
            }
        }

        private void btnDeleteAll_Click(object sender, EventArgs e) //Delete the selected rows data
        {
            string repairstatus = "Incomplete";
            string repaircollectiondate = "";
            string repairdescription = "";

            
            set = "Status = '" + repairstatus + "', CollectionDate = '" + repaircollectiondate + "', Description = '" + repairdescription + "'";
            condition = "Username = '" + txtUsername.Text + "'";

            if (checkBox1.Checked)
            {
                bool request = TCSM.Updatedb(set, condition);
                if (request)
                {
                    MessageBox.Show("Successfully Updated", "Update Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Database Connection Error", "Error Occured", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                loaddata();
                resetinput();
            }
            else
            {
                MessageBox.Show("Please tick the checkbox before procceed", "Selection Invalid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

           

        }
    }
}
