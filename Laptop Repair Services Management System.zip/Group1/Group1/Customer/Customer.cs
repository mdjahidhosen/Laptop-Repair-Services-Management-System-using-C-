﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Collections;

namespace Group1
{
    internal class Customer
    {
        private string MemberID;
        private string FirstName;
        private string LastName;
        private string Username;
        private string PhoneNumber;
        private string ICPassport;
        private string BirthDate;
        private string Email;
        private string Address;
        private string Password;
        private string ConfirmPassword;
        static SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());


        public string LastName1 { get => LastName; set => LastName = value; }
        public string Username1 { get => Username; set => Username = value; }
        public string PhoneNumber1 { get => PhoneNumber; set => PhoneNumber = value; }
        public string ICPassport1 { get => ICPassport; set => ICPassport = value; }
        public string BirthDate1 { get => BirthDate; set => BirthDate = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string Address1 { get => Address; set => Address = value; }
        public string ConfirmPassword1 { get => ConfirmPassword; set => ConfirmPassword = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string FirstName1 { get => FirstName; set => FirstName = value; }
        public string MemberID1 { get => MemberID; set => MemberID = value; }

        public Customer(string fn, string ln, string un, string pn, string ip, string bd, string em, string ad, string pw, string cw)
        {
            FirstName = fn;
            LastName = ln;
            Username = un;
            PhoneNumber = pn;
            ICPassport = ip;
            BirthDate1 = bd;
            Email = em;
            Address = ad;
            Password = pw;
            ConfirmPassword = cw;
        }
        public Customer(string mid)
        {
            MemberID = mid;
        }

        public static void viewProfile(Customer o1)
        {
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Registration where FirstName = '" + o1.MemberID + "'", cn);
            SqlDataReader dr = cmd.ExecuteReader();

            while(dr.Read())
            {
                o1.MemberID = dr.GetString(0);
                o1.FirstName = dr.GetString(1);
                o1.LastName = dr.GetString(2);
                o1.Username = dr.GetString(3);
                o1.PhoneNumber = dr.GetString(5);
                o1.ICPassport = dr.GetString(6);
                o1.BirthDate = dr.GetDateTime(7).ToShortDateString(); 
                o1.Email = dr.GetString(8);
                o1.Address = dr.GetString(9);
                o1.Password = dr.GetString(10);
                o1.ConfirmPassword = dr.GetString(11);
            }
            cn.Close();

        }
        public string updateCustomer(string fn,string ln, string un, string pn, string ip, string bd, string em, string ad, string pw, string cw)
        {
            string status;
            cn.Open();

            FirstName = fn;
            LastName = ln;
            Username = un;
            PhoneNumber = pn;
            ICPassport = ip;
            BirthDate = bd;
            Email = em;
            Address = ad;
            Password = pw;
            ConfirmPassword = cw;

            SqlCommand cmd = new SqlCommand("update registration set FirstName = '" + FirstName + "', LastName = '" + LastName + "', Username = '" + Username + "',PhoneNumber  = '" + PhoneNumber + "', ICPassport  = '" + ICPassport + "', BirthDate = '" + BirthDate + "' , Email = '" + Email + "', Address = '" + Address + "', Password = '" + Password + "', ConfirmPassword = '" + ConfirmPassword + "' where MemberID = '" + MemberID + "'", cn);
            int i = cmd.ExecuteNonQuery();

            if (i != 0)
                status = "Your Profile Already Updated";
            else
                status = "Unable to Update";
            cn.Close();

            return status;
        }
    }
}
