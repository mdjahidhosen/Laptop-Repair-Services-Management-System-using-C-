﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group1
{
    public partial class frmFN : Form
    {
        public frmFN()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            frmUpdateCust f2 = new frmUpdateCust(this);
            f2.ShowDialog();
            this.Hide();
           
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmCustHome f3 = new frmCustHome();
            f3.Show();
            this.Hide();

        }
    }
}
