﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;

namespace Group1
{
    internal class Services
    {
        private string OrderID;
        private string Username;
        private string Description;
        private string CollectionDate;
        private string TotalAmount;
        private string RequestService;
        private string DateRequest;
        private string ServiceType;
        private string ServicePrice;

        static SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ToString());

        public string Description1 { get => Description; set => Description = value; }
        public string CollectionDate1 { get => CollectionDate; set => CollectionDate = value; }
        public string TotalAmount1 { get => TotalAmount; set => TotalAmount = value; }
        public string RequestService1 { get => RequestService; set => RequestService = value; }
        public string DateRequest1 { get => DateRequest; set => DateRequest = value; }
        public string ServiceType1 { get => ServiceType; set => ServiceType = value; }
        public string ServicePrice1 { get => ServicePrice; set => ServicePrice = value; }
        public string OrderID1 { get => OrderID; set => OrderID = value; }
        public string Username1 { get => Username; set => Username = value; }

        public Services(string oid,string un, string d, string cd, string ta, string rs, string dt, string st, string sp)
        {
            Username = un;
            Description = d;
            CollectionDate = cd;
            TotalAmount = ta;
            RequestService = rs;
            DateRequest = dt;
            ServiceType = st;
            ServicePrice = sp;
        }
        public Services(string oid, string un, string rs, string dt, string st, string sp)
        {
            OrderID=oid;
            Username = un;
            RequestService = rs;
            DateRequest = dt;
            ServiceType = st;
            ServicePrice = sp;
        }
        public Services(string un, string oi)
        {
            Username = un;
            OrderID = oi;
        }
        public Services(string oi)
        {
            OrderID = oi;
        }
        public static ArrayList viewService()
        {
            ArrayList nm = new ArrayList();
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Services", cn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                /*Description = dr.GetString(2);
                nm.Add(dr.GetString(0));
                /*nm.Add(dr.GetDateTime(8).ToShortDateString());
                nm.Add(dr.GetString(9));*/
            }
            cn.Close();
            return nm;
        }
        public static void viewService1(Services o1)
        {
       
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Services where OrderID='" + o1.OrderID+"'", cn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                o1.Description = dr.GetString(9);
                o1.CollectionDate = dr.GetString(8);
                o1.TotalAmount = dr.GetDecimal(10).ToString();
            }
            cn.Close();

        }
        public static void getUsername(Services o2)
        {

            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from Services where OrderID='" + o2.OrderID + "'", cn);
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                o2.Username = dr.GetString(1);
            }
            cn.Close();

        }

        public string addrequest()
        {
            string status;
            cn.Open();
            SqlCommand cmd = new SqlCommand("insert into ChangeRequest(OrderID, Username, RequestService, DateRequest, ServiceType, ServicePrice) values (@oid, @user, @req, @datereq, @sertype, @serprice)", cn);
            cmd.Parameters.AddWithValue("@oid", OrderID);
            cmd.Parameters.AddWithValue("@user", Username);
            cmd.Parameters.AddWithValue("@req", RequestService);
            cmd.Parameters.AddWithValue("@datereq", DateRequest);
            cmd.Parameters.AddWithValue("@sertype", ServiceType);
            cmd.Parameters.AddWithValue("@serprice", ServicePrice);

            int i = cmd.ExecuteNonQuery();
            if (i != 0)
                status = "Your Request has been sent ";
            else
                status = "Request Failed";
            cn.Close();
            return status;
        }
    }
}
