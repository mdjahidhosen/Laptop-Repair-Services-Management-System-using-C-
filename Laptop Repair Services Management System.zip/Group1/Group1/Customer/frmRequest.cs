﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group1
{
    public partial class frmRequest : Form
    {
        public frmRequest()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Remove virus, malware or spyware");
            comboBox1.Items.Add("roubleshot and fix computer running slow");
            comboBox1.Items.Add("Laptop screen replacement");
            comboBox1.Items.Add("Laptop keyboard replacement");
            comboBox1.Items.Add("Laptop battery replacement");
            comboBox1.Items.Add("Operating System Format and Installation");
            comboBox1.Items.Add("Data backup and recovery");
            comboBox1.Items.Add("Internet connectivity issues");
            comboBox2.Items.Add("Normal");
            comboBox2.Items.Add("Urgent");
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Remove virus, malware or spyware")
            {
                lblPrice.Text = "50 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Remove virus, malware or spyware")
            {
                lblPrice.Text = "80 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Troubleshot and fix computer running slow")
            {
                lblPrice.Text = "60 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Troubleshot and fix computer running slow")
            {
                lblPrice.Text = "90 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop screen replacement")
            {
                lblPrice.Text = "380 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop screen replacement")
            {
                lblPrice.Text = "430 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop keyboard replacement")
            {
                lblPrice.Text = "160 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop keyboard replacement")
            {
                lblPrice.Text = "200 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Laptop battery replacement")
            {
                lblPrice.Text = "180 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Laptop battery replacement")
            {
                lblPrice.Text = "210 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Operating System Format and Installation")
            {
                lblPrice.Text = "100 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Operating System Format and Installation")
            {
                lblPrice.Text = "150 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Data backup and recovery")
            {
                lblPrice.Text = "80 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Data backup and recovery")
            {
                lblPrice.Text = "130 RM";
            }
            else if (comboBox2.SelectedItem == "Normal" && comboBox1.SelectedItem == "Internet connectivity issues")
            {
                lblPrice.Text = "70 RM";
            }
            else if (comboBox2.SelectedItem == "Urgent" && comboBox1.SelectedItem == "Internet connectivity issues")
            {
                lblPrice.Text = "100 RM";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmCustHome f1 = new frmCustHome();
            f1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                MessageBox.Show("Please Confirm The Details");
            }
            else if (checkBox1.Checked == true)
            {
                Services obj1 = new Services(txtOrderID.Text, txtUser.Text, comboBox1.Text, DateReq.Text, comboBox2.Text, lblPrice.Text);
                MessageBox.Show(obj1.addrequest());
                Clear();
            }
        }

        private void Clear()
        {
            txtUser.Text = " ";
            comboBox1.Text = " ";
            comboBox2.Text = " ";
            lblPrice.Text = " ";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Services obj2 = new Services(txtOrderID.Text);
            Services.getUsername(obj2);

            txtOrderID.Text = obj2.OrderID1;
            txtUser.Text = obj2.Username1;
        }
    }
}
