﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group1
{
    public partial class frmCustHome : Form
    {
        public static string FirstName;

        public frmCustHome()
        {
            InitializeComponent();
        }

        public frmCustHome(string f)
        {
            InitializeComponent();
            FirstName = f;
        }

        private void frmCustHome_Load(object sender, EventArgs e)
        {
            lblRole.Text = "Welcome, " + FirstName + " To Customer Homepage";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmFN f1 = new frmFN();
            f1.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmView f1 = new frmView();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmRequest f1 = new frmRequest();
            f1.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            UserLogin f2 = new UserLogin();
            f2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
