﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Group1
{
    public partial class frmUpdateCust : Form
    {
        frmFN f1;
        public static string Username;
        public frmUpdateCust()
        {
            InitializeComponent();
        }
        public frmUpdateCust(frmFN frm1)
        {
            InitializeComponent();
            this.f1 = frm1;
        }
        public frmUpdateCust(string un)
        {
            InitializeComponent();
            Username = un;
        }

        private void frmUpdateCust_Load(object sender, EventArgs e)
        {
            Customer obj1 = new Customer(Username);
            Customer.viewProfile(obj1);


            txtFirstName.Text = obj1.FirstName1;
            txtLastName.Text = obj1.LastName1;
            txtUsername.Text = obj1.Username1;
            txtPhoneNum.Text = obj1.PhoneNumber1;
            txtEmail.Text = obj1.Email1;
            txtICP.Text = obj1.ICPassport1;
            txtAdd.Text = obj1.Address1;
            this.dtp1.Text = obj1.BirthDate1;
            txtPass.Text = obj1.Password1;
            txtCPass.Text = obj1.ConfirmPassword1;


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (chkConfirm.Checked == false)
            {
                MessageBox.Show("Please Confirm The Details");
            }
            else if (chkConfirm.Checked == true)
            {
                Customer obj1 = new Customer(f1.txtConFN.Text);
                obj1.MemberID1 = f1.txtConFN.Text;
                MessageBox.Show(obj1.updateCustomer(txtFirstName.Text, txtLastName.Text, txtUsername.Text, txtPhoneNum.Text, txtICP.Text, this.dtp1.Text, txtEmail.Text, txtAdd.Text, txtPass.Text, txtCPass.Text));

                Clear();
            }
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmCustHome f1 = new frmCustHome();
            f1.Show();
            this.Close();
        }
        private void Clear()
        {
            txtAdd.Text = " ";
            txtCPass.Text = "";
            txtEmail.Text = " ";
            txtFirstName.Text = " ";
            txtLastName.Text = " ";
            txtPhoneNum.Text = " ";
            txtUsername.Text = " ";
            txtICP.Text = " ";
            txtPass.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void checkBoxPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxPass.Checked == true)
            {
                txtPass.UseSystemPasswordChar = false;
                txtCPass.UseSystemPasswordChar = false;
            }
            else if (checkBoxPass.Checked == false)
            {
                txtPass.UseSystemPasswordChar = true;
                txtCPass.UseSystemPasswordChar = true;
            }
        }


        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEmail = new System.Text.RegularExpressions.Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            if(txtEmail.Text.Length > 0)
            {
                if(!rEmail.IsMatch(txtEmail.Text))
                {
                    MessageBox.Show("Invalid email address", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtEmail.SelectAll();
                    e.Cancel = true;
                }
            }
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {

        }
    }
}
