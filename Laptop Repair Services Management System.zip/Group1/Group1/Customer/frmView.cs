﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Group1
{
    public partial class frmView : Form
    {
        public static string Username;
        public frmView()
        {
            InitializeComponent();
        }
        public frmView(string un)
        {
            InitializeComponent();
            Username = un;
        }

        private void frmView_Load(object sender, EventArgs e)
        {
            /*ArrayList name = new ArrayList();
            name = Services.viewService();
            foreach (var item in name)
            {
                txtDescView.Text = item.ToString();
                txtCollectionDate.Text = item.ToString();
                txtTotalView.Text = item.ToString();
            }*/
            
           /* Services obj1 = new Services(txtUsername.Text);
            Services.viewService1(obj1);

            txtDescView.Text = obj1.Description1;
            txtCollectionDate.Text = obj1.CollectionDate1;
            txtTotalView.Text = obj1.TotalAmount1;*/

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmCustHome f1 = new frmCustHome();
            f1.Show();
            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Services obj1 = new Services(txtUsername.Text);
            Services.viewService1(obj1);

            txtDescView.Text = obj1.Description1;
            txtCollectionDate.Text = obj1.CollectionDate1;
            txtTotalView.Text = obj1.TotalAmount1 + " RM";
        }
    }
}
